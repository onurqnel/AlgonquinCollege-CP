/**
 * @file TravelRecord.h
 * @author Onur Onel
 * @studentID 041074824
 * @date 09-22-2023
 * @brief Assignment 01 Practical Project: Defines the TravelRecord class for the main method operations
 */

#ifndef ASSIGNMENT01_TRAVELRECORD_H  ///< Checks if the header has been included before
#define ASSIGNMENT01_TRAVELRECORD_H  ///< Defines the include guard to prevent multiple inclusions

#include <string>  ///< Added for string manipulations

/**
 * @class TravelRecord
 * @brief Stores travel record information, including reference number, disclosure group, and title
 */
class TravelRecord {
public:

    std::string ref_number;
    std::string disclosure_group;
    std::string title_en;

    /**
     * @brief Gets the reference number
     * @return The reference number as a string
     */
    std::string getRefNumber() const {
        return ref_number;
    }

    /**
     * @brief Sets the reference number
     * @param refNumber The reference number to set
     */
    void setRefNumber(const std::string &refNumber) {
        ref_number = refNumber;
    }

    /**
     * @brief Gets the disclosure group
     * @return The disclosure group as a string
     */
    std::string getDisclosureGroup() const {
        return disclosure_group;
    }

    /**
     * @brief Sets the disclosure group
     * @param disclosureGroup The disclosure group to set
     */
    void setDisclosureGroup(const std::string &disclosureGroup) {
        disclosure_group = disclosureGroup;
    }

    /**
     * @brief Gets the title in English
     * @return The title in English as a string
     */
    std::string getTitleEn() const {
        return title_en;
    }

    /**
     * @brief Sets the title in English
     * @param titleEn The title in English to set
     */
    void setTitleEn(const std::string &titleEn) {
        title_en = titleEn;
    }
};

#endif //ASSIGNMENT01_TRAVELRECORD_H
