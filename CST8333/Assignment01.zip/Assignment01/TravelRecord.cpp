/**
 * @file TravelRecord.cpp
 * @author Onur Onel
 * @studentID 041074824
 * @date 09-22-2023
 * @brief Assignment 01 Practical Project: Reads travel records from a CSV file and stores them in a vector of TravelRecord objects.
 */

#include "TravelRecord.h"  ///< Included the header file for the TravelRecord class
#include "csv-parser-master/csv-parser-master/include/csv.hpp"  ///< Included the CSV parser library from https://github.com/vincentlaucsb/csv-parser
#include <iostream>  ///< Added for standard I/O operations
#include <vector>  ///< Added for using the vector data structure
#include <exception>  ///< Added for exception handling

using namespace std;  ///< Used the standard namespace

/**
 * @brief The main function where the program starts execution.
 * @return Returns 0 upon successful completion.
 */
int main() {
    cout << "Full Name: Onur Onel" << endl << endl;

    vector<TravelRecord> records;  ///< Created vector to store TravelRecord objects

    try {
        /// Created a CSVReader object to read the travelq.csv file
        csv::CSVReader reader(R"(C:\Users\ONUR\CLionProjects\Assignment01\travelq.csv)");

        /// Iterated over each row in the travelq.csv file
        for (csv::CSVRow &row : reader) {
            try {
                TravelRecord record;  ///< Created a TravelRecord object

                /// Populated the TravelRecord object with relevant data extracted from the csv row
                /// It sets the reference number, disclosure group, and title
                record.setRefNumber(row["ref_number"].get<string>());
                record.setDisclosureGroup(row["disclosure_group"].get<string>());
                record.setTitleEn(row["title_en"].get<string>());

                records.push_back(record);  ///< Added the TravelRecord object to the vector

            } catch (const std::exception &e) {
                cout << "Error reading row: " << e.what() << endl;  ///< Handling exceptions that occur while reading a row
            }
        }

        cout << "Records:" << endl;
        int counter = 0;  ///< Counter for limiting the number of displayed records

        /// Loop through the vector and displayed the first five TravelRecord row
        for (const TravelRecord &record : records) {
            if (counter >= 5) {
                break;
            } else {
                cout << "Ref Number: " << record.getRefNumber()
                     << ", Disclosure Group: " << record.getDisclosureGroup()
                     << ", Title (EN): " << record.getTitleEn() << endl;
                ++counter;  ///< Incrementing the counter
            }
        }

    } catch (const exception &e) {
        cout << "Error reading CSV: " << e.what() << endl;  ///< Handling exceptions that occur while reading the CSV file
    }

    return 0;  ///< Exit the program
}
