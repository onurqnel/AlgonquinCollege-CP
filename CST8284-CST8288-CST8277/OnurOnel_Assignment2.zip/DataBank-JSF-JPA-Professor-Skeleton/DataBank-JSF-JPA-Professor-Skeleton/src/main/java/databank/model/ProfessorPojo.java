/**
 * Name: Onur Onel
 * Student Number: 041074824
 * Institution: Algonquin College
 * Course: Enterprise Application Programming
 * Lab: 321
 */
package databank.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

import javax.faces.view.ViewScoped;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Version;

@ViewScoped
@Entity(name = "Professor")
@Table(name = "professor", catalog = "databank", schema = "")
@Access(AccessType.FIELD)
@EntityListeners(ProfessorPojoListener.class)
@NamedQuery(name = ProfessorPojo.PROFESSOR_FIND_ALL, query = "SELECT p FROM Professor p")
@NamedQuery(name = ProfessorPojo.PROFESSOR_FIND_ID, query = "SELECT p FROM Professor p WHERE p.id = :id")
public class ProfessorPojo implements Serializable {
	private static final long serialVersionUID = 1L;

	public static final String PROFESSOR_FIND_ALL = "Professor.findAll";
	public static final String PROFESSOR_FIND_ID = "Professor.findById";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Basic
	@Column(name = "last_name", nullable = false, length = 100)
	private String lastName;

	@Basic
	@Column(name = "first_name", nullable = false, length = 100)
	private String firstName;

	@Basic
	@Column(name = "email", nullable = false)
	private String email;

	@Basic
	@Column(name = "phoneNumber", nullable = false)
	private String phoneNumber;

	@Basic
	@Column(name = "degree", nullable = true, length = 100)
	private String degree;

	@Basic
	@Column(name = "major", nullable = true, length = 100)
	private String major;

	@Basic
	@Column(name = "created", nullable = false)
	private LocalDateTime created;

	@Basic
	@Column(name = "updated", nullable = false)
	private LocalDateTime updated;

	@Version
	@Column(name = "version")
	private int version = 1;

	@Version
	@Column(name = "editable")
	private boolean editable;

	public ProfessorPojo() {
		super();
	}

	public boolean getEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public LocalDateTime getCreated() {
		return created;
	}

	public void setCreated(LocalDateTime created) {
		this.created = created;
	}

	public LocalDateTime getUpdated() {
		return updated;
	}

	public void setUpdated(LocalDateTime updated) {
		this.updated = updated;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public static String getProfessorFindAll() {
		return PROFESSOR_FIND_ALL;
	}

	public static String getProfessorFindId() {
		return PROFESSOR_FIND_ID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		return prime * result + Objects.hash(getId());
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (obj instanceof ProfessorPojo otherProfessorPojo) {
			return Objects.equals(this.getId(), otherProfessorPojo.getId());
		}
		return false;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Professor [id = ").append(getId());
		if (getLastName() != null) {
			builder.append(", ").append("lastName = ").append(getLastName());
		}
		if (getFirstName() != null) {
			builder.append(", ").append("firstName = ").append(getFirstName());
		}
		if (getPhoneNumber() != null) {
			builder.append(", ").append("phoneNumber = ").append(getPhoneNumber());
		}
		if (getEmail() != null) {
			builder.append(", ").append("email = ").append(getEmail());
		}
		if (getCreated() != null) {
			builder.append(", ").append("created = ").append(getCreated());
		}
		if (getUpdated() != null) {
			builder.append(", ").append("updated = ").append(getUpdated());
		}
		if (getDegree() != null) {
			builder.append(", ").append("degree = ").append(getDegree());
		}
		if (getMajor() != null) {
			builder.append(", ").append("major = ").append(getMajor());
		}
		builder.append("]");
		return builder.toString();
	}
}
