/**
 * Name: Onur Onel
 * Student Number: 041074824
 * Institution: Algonquin College
 * Course: Enterprise Application Programming
 * Lab: 321
 */
package databank.dao;

import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import databank.model.ProfessorPojo;
import java.util.List;

@Singleton
public class ProfessorService {

	@PersistenceContext(name = "PU_DataBank")
	protected EntityManager em;

	public ProfessorService() {
	}

	public List<ProfessorPojo> readAllProfessors() {
		TypedQuery<ProfessorPojo> allProfessorsQuery = em.createNamedQuery(ProfessorPojo.PROFESSOR_FIND_ALL,
				ProfessorPojo.class);
		return allProfessorsQuery.getResultList();
	}

	@Transactional
	public ProfessorPojo createProfessor(ProfessorPojo professor) {
		em.persist(professor);
		return professor;
	}

	public ProfessorPojo readProfessorById(int professorId) {
		return em.find(ProfessorPojo.class, professorId);
	}

	@Transactional
	public ProfessorPojo updateProfessor(ProfessorPojo professorWithUpdates) {
		return em.merge(professorWithUpdates);
	}

	@Transactional
	public void deleteProfessorById(int professorId) {
		ProfessorPojo professor = readProfessorById(professorId);
		if (professor != null) {
			em.remove(professor);
		}
	}
}
