/**
 * Name: Onur Onel
 * Student Number: 041074824
 * Institution: Algonquin College
 * Course: Enterprise Application Programming
 * Lab: 321
 */
package databank.dao;

import java.util.List;

import databank.model.ProfessorPojo;

public interface ProfessorDao {

	List<ProfessorPojo> readAllProfessors();

	ProfessorPojo createProfessor(ProfessorPojo professor);

	ProfessorPojo readProfessorById(int professorId);

	ProfessorPojo updateProfessor(ProfessorPojo professor);

	void deleteProfessorById(int professorId);

}
