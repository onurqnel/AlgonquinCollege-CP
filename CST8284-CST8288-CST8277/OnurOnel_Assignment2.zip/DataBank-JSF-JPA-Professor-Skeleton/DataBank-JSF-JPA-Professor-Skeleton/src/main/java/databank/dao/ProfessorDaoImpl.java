/**
 * Name: Onur Onel
 * Student Number: 041074824
 * Institution: Algonquin College
 * Course: Enterprise Application Programming
 * Lab: 321
 */
package databank.dao;

import java.io.Serializable;
import java.util.List;

import javax.ejb.EJB;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import databank.model.ProfessorPojo;

@Named
@ApplicationScoped
public class ProfessorDaoImpl implements ProfessorDao, Serializable {

	private static final long serialVersionUID = 1L;

	private static final Logger LOG = LogManager.getLogger();

	@EJB
	private ProfessorService professorService;

	@Override
	public List<ProfessorPojo> readAllProfessors() {
		LOG.debug("reading all professors");
		return professorService.readAllProfessors();
	}

	@Override
	public ProfessorPojo createProfessor(ProfessorPojo professor) {
		LOG.debug("creating a professor = {}", professor);
		return professorService.createProfessor(professor);
	}

	@Override
	public ProfessorPojo readProfessorById(int professorId) {
		LOG.debug("read a specific professor = {}", professorId);
		return professorService.readProfessorById(professorId);
	}

	@Override
	public ProfessorPojo updateProfessor(ProfessorPojo professorWithUpdates) {
		LOG.debug("updating a specific professor = {}", professorWithUpdates);
		return professorService.updateProfessor(professorWithUpdates);
	}

	@Override
	public void deleteProfessorById(int professorId) {
		LOG.debug("deleting a specific professorID = {}", professorId);
		professorService.deleteProfessorById(professorId);
	}
}
