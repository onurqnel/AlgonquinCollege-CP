/**
 * Name: Onur Onel
 * Student Number: 041074824
 * Institution: Algonquin College
 * Course: Enterprise Application Programming
 * Lab: 321
 */
package databank.dao;

import java.util.List;

public interface ListDataDao {

	public List<String> readAllDegrees();

	public List<String> readAllMajors();

}