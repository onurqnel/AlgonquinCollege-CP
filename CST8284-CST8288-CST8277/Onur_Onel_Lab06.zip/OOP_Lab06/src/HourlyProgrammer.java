/**
 * Student Name: Onur Onel
 * 
 * Lab Professor: 
 * 
 * Due Date: March 31, 2023 11:59 PM
 * 
 * Project Name: Lab06
 **/
/**
 * 
 * Represents a programmer who earns an hourly wage.
 * 
 * Extends the Programmer class and adds wage and hours fields and related
 * methods.
 */
public class HourlyProgrammer extends Programmer {

	/**
	 * The hourly wage earned by the programmer
	 */
	private double wage;

	/**
	 * The number of hours worked by the programmer
	 */
	private double hours;

	/**
	 * 
	 * Constructs an HourlyProgrammer object with the specified attributes.
	 * 
	 * @param firstName            the first name of the programmer
	 * 
	 * @param lastName             the last name of the programmer
	 * 
	 * @param socialSecurityNumber the social security number of the programmer
	 * 
	 * @param month                the birth month of the programmer
	 * 
	 * @param year                 the birth year of the programmer
	 * 
	 * @param wage                 the hourly wage earned by the programmer
	 * 
	 * @param hours                the number of hours worked by the programmer
	 * 
	 * @throws IllegalArgumentException if the wage is negative or if the hours
	 *                                  worked are not within the valid range
	 */
	public HourlyProgrammer(String firstName, String lastName, String socialSecurityNumber, int month, int year,
			double wage, double hours) {
		super(firstName, lastName, socialSecurityNumber);

		if (wage < 0.0) {
			throw new IllegalArgumentException("Hourly wage must be >= 0.0");
		}

		if ((hours < 0.0) || (hours > 168.0)) {
			throw new IllegalArgumentException("Hours worked must be >= 0.0 and <= 168.0");
		}

		this.wage = wage;
		this.hours = hours;
	}

	/**
	 * 
	 * Sets the hourly wage of the programmer.
	 * 
	 * @param wage the new hourly wage
	 * 
	 * @throws IllegalArgumentException if the wage is negative
	 */
	public void setWage(double wage) {
		if (wage < 0.0) {
			throw new IllegalArgumentException("Hourly wage must be >= 0.0");
		}

		this.wage = wage;
	}

	/**
	 * 
	 * Returns the hourly wage of the programmer.
	 * 
	 * @return the hourly wage
	 */
	public double getWage() {
		return wage;
	}

	/**
	 * 
	 * Sets the number of hours worked by the programmer.
	 * 
	 * @param hours the new number of hours worked
	 * 
	 * @throws IllegalArgumentException if the hours worked are not within the valid
	 *                                  range
	 */
	public void setHours(double hours) {
		if ((hours < 0.0) || (hours > 168.0)) {
			throw new IllegalArgumentException("Hours worked must be >= 0.0 and <= 168.0");
		}

		this.hours = hours;
	}

	/**
	 * 
	 * Returns the number of hours worked by the programmer.
	 * 
	 * @return the number of hours worked
	 */
	public double getHours() {
		return hours;
	}

	/**
	 * 
	 * Calculates and returns the earnings for the programmer. The earnings are the
	 * product of the hourly wage and the number of hours worked. Overtime is paid
	 * at 1.5 times the hourly wage for hours worked over 40.
	 * 
	 * @return the earnings
	 */
	@Override
	public double earnings() {
		if (getHours() <= 40) {
			return getWage() * getHours();
		} else {
			return 40 * getWage() + (getHours() - 40) * getWage() * 1.5;
		}
	}

	/**
	 * 
	 * Returns a string representation of the HourlyProgrammer object.
	 * 
	 * @return a string representation of the programmer
	 */
	@Override
	public String toString() {
		return String.format("%s " + super.toString() + "\n%s: $%.2f; %s: %.2f", "hourly", "hourly wage", getWage(),
				"hours worked", getHours());
	}

	/**
	 * 
	 * Returns the payment amount for the programmer, which is equal to their
	 * earnings.
	 * 
	 * @return the payment amount
	 */
	@Override
	public double getPaymentAmount() {
		return earnings();
	}
}