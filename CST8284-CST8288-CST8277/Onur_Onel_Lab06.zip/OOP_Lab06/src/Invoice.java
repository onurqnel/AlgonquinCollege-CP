/**
 * Student Name: Onur Onel
 * 
 * Lab Professor: 
 * 
 * Due Date: March 31, 2023 11:59 PM
 * 
 * Project Name: Lab06
 **/
/**
 * 
 * A class representing an invoice that can be paid.
 * 
 * Implements the Payme interface and defines fields and methods for invoices.
 */
public class Invoice implements Payme {

	/**
	 * The part number for the invoice
	 */
	private String partNumber;
	/**
	 * The description for the invoice
	 */
	private String partDescription;
	/**
	 * The quantity for the invoice
	 */
	private int quantity;
	/**
	 * The price per item for the invoice
	 */
	private double pricePerItem;

	/**
	 * 
	 * Constructs an Invoice object with the specified attributes.
	 * 
	 * @param partNumber      the part number for the invoice
	 * @param partDescription the description for the invoice
	 * @param quantity        the quantity for the invoice
	 * @param pricePerItem    the price per item for the invoice
	 */
	public Invoice(String partNumber, String partDescription, int quantity, double pricePerItem) {
		this.partNumber = partNumber;
		this.partDescription = partDescription;
		setQuantity(quantity);
		setPricePerItem(pricePerItem);
	}

	/**
	 * 
	 * Sets the part number for the invoice.
	 * 
	 * @param partNumber the new part number
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	/**
	 * 
	 * Returns the part number for the invoice.
	 * 
	 * @return the part number
	 */
	public String getPartNumber() {
		return partNumber;
	}

	/**
	 * 
	 * Sets the description for the invoice.
	 * 
	 * @param partDescription the new description
	 */
	public void setPartDescription(String partDescription) {
		this.partDescription = partDescription;
	}

	/**
	 * 
	 * Returns the description for the invoice.
	 * 
	 * @return the description
	 */
	public String getPartDescription() {
		return partDescription;
	}

	/**
	 * 
	 * Sets the quantity for the invoice.
	 * 
	 * @param quantity the new quantity
	 */
	public void setQuantity(int quantity) {
		this.quantity = (quantity < 0) ? 0 : quantity; // quantity cannot be negative
	}

	/**
	 * 
	 * Returns the quantity for the invoice.
	 * 
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * 
	 * Sets the price per item for the invoice.
	 * 
	 * @param pricePerItem the new price per item
	 */
	public void setPricePerItem(double pricePerItem) {
		this.pricePerItem = (pricePerItem < 0.0) ? 0.0 : pricePerItem; // validate price
	}

	/**
	 * 
	 * Returns the price per item for the invoice.
	 * 
	 * @return the price per item
	 */
	public double getPricePerItem() {
		return pricePerItem;
	}

	/**
	 * 
	 * Returns a string representation of the Invoice object.
	 * 
	 * @return a string representation of the invoice
	 */
	@Override
	public String toString() {
		return String.format("%s: %n%s: %s (%s) %n%s: %d %n%s: $%,.2f", "Invoice", "part number", getPartNumber(),
				getPartDescription(), "quantity", getQuantity(), "price per item", getPricePerItem());
	}

	/**
	 * 
	 * Returns the payment amount for the invoice.
	 * 
	 * @return the payment amount
	 */
	@Override
	public double getPaymentAmount() {
		return getQuantity() * getPricePerItem();
	}
}