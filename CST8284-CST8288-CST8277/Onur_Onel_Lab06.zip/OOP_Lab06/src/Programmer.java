/**
 * Student Name: Onur Onel
 * 
 * Lab Professor: 
 * 
 * Due Date: March 31, 2023 11:59 PM
 * 
 * Project Name: Lab06
 **/
/**
 * 
 * An abstract class representing a programmer who can be paid.
 * 
 * Implements the Payme interface and defines common fields and methods for all
 * Programmer types.
 */
public abstract class Programmer implements Payme {

	/**
	 * The first name of the programmer
	 */
	private String firstName;
	/**
	 * The last name of the programmer
	 */
	private String lastName;
	/**
	 * The social security number of the programmer
	 */
	private String socialSecurityNumber;

	/**
	 * 
	 * Constructs a Programmer object with the specified attributes.
	 * 
	 * @param firstName            the first name of the programmer
	 * @param lastName             the last name of the programmer
	 * @param socialSecurityNumber the social security number of the programmer
	 */
	public Programmer(String firstName, String lastName, String socialSecurityNumber) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.socialSecurityNumber = socialSecurityNumber;
	}

	/**
	 * 
	 * Returns the first name of the programmer.
	 * 
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * 
	 * Sets the first name of the programmer.
	 * 
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * 
	 * Returns the last name of the programmer.
	 * 
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * 
	 * Sets the last name of the programmer.
	 * 
	 * @param lastName the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * 
	 * Returns the social security number of the programmer.
	 * 
	 * @return the social security number
	 */
	public String getSocialSecurityNumber() {
		return socialSecurityNumber;
	}

	/**
	 * 
	 * Sets the social security number of the programmer.
	 * 
	 * @param socialSecurityNumber the new social security number
	 */
	public void setSocialSecurityNumber(String socialSecurityNumber) {
		this.socialSecurityNumber = socialSecurityNumber;
	}

	/**
	 * 
	 * Returns a string representation of the Programmer object.
	 * 
	 * @return a string representation of the programmer
	 */
	@Override
	public String toString() {
		return String.format("%s: %s %s%n%s: %s", "Programmer", getFirstName(), getLastName(), "social security number",
				getSocialSecurityNumber());
	}

	/**
	 * 
	 * Returns the earnings for the programmer. Each subclass must implement this
	 * method.
	 * 
	 * @return the earnings
	 */
	public abstract double earnings();
}