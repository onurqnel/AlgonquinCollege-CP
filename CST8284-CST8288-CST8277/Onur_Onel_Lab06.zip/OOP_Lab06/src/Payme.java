/**
 * Student Name: Onur Onel
 * 
 * Lab Professor: 
 * 
 * Due Date: March 31, 2023 11:59 PM
 * 
 * Project Name: Lab06
 **/
/**
 * 
 * An interface representing an object that can be paid.
 * 
 * Defines a method for getting the payment amount.
 */
public interface Payme {

	/**
	 * 
	 * Returns the payment amount for the object that implements this interface.
	 * Each implementing class must provide an implementation for this method.
	 * 
	 * @return the payment amount
	 */
	double getPaymentAmount();
}