/**
 * Student Name: Onur Onel
 * 
 * Lab Professor: 
 * 
 * Due Date: March 31, 2023 11:59 PM
 * 
 * Project Name: Lab06
 **/
/**
 * 
 * Represents a programmer who earns a fixed weekly salary.
 * 
 * Extends the Programmer class and adds a weeklySalary field and related
 * methods.
 */
public class SalariedProgrammer extends Programmer {

	/**
	 * The fixed weekly salary earned by the programmer
	 */
	private double weeklySalary;

	/**
	 * 
	 * Constructs a SalariedProgrammer object with the specified attributes.
	 * 
	 * @param firstName            the first name of the programmer
	 * 
	 * @param lastName             the last name of the programmer
	 * 
	 * @param socialSecurityNumber the social security number of the programmer
	 * 
	 * @param month                the birth month of the programmer
	 * 
	 * @param year                 the birth year of the programmer
	 * 
	 * @param weeklySalary         the fixed weekly salary earned by the programmer
	 * 
	 * @throws IllegalArgumentException if the weekly salary is negative
	 */
	public SalariedProgrammer(String firstName, String lastName, String socialSecurityNumber, int month, int year,
			double weeklySalary) {
		super(firstName, lastName, socialSecurityNumber);

		if (weeklySalary < 0.0) {
			throw new IllegalArgumentException("Weekly salary must be >= 0.0");
		}

		this.weeklySalary = weeklySalary;
	}

	/**
	 * 
	 * Sets the weekly salary of the programmer.
	 * 
	 * @param weeklySalary the new weekly salary
	 * 
	 * @throws IllegalArgumentException if the weekly salary is negative
	 */
	public void setWeeklySalary(double weeklySalary) {
		if (weeklySalary < 0.0) {
			throw new IllegalArgumentException("Weekly salary must be >= 0.0");
		}

		this.weeklySalary = weeklySalary;
	}

	/**
	 * 
	 * Returns the weekly salary of the programmer.
	 * 
	 * @return the weekly salary
	 */
	public double getWeeklySalary() {
		return weeklySalary;
	}

	/**
	 * 
	 * Returns the earnings for the programmer, which is equal to their fixed weekly
	 * salary.
	 * 
	 * @return the earnings
	 */
	@Override
	public double earnings() {
		return getWeeklySalary();
	}

	/**
	 * 
	 * Returns a string representation of the SalariedProgrammer object.
	 * 
	 * @return a string representation of the programmer
	 */
	@Override
	public String toString() {
		return String.format("Salaried %s%n%s: $%.2f ", super.toString(), "weekly salary", getWeeklySalary());
	}

	/**
	 * 
	 * Returns the payment amount for the programmer, which is equal to their
	 * earnings.
	 * 
	 * @return the payment amount
	 */
	@Override
	public double getPaymentAmount() {
		return earnings();
	}
}