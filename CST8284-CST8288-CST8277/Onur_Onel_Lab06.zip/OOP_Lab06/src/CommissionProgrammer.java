/**
 * Student Name: Onur Onel
 * 
 * Lab Professor: 
 * 
 * Due Date: March 31, 2023 11:59 PM
 * 
 * Project Name: Lab06
 **/
/**
 * 
 * Represents a programmer who earns a commission based on their gross sales.
 * 
 * Extends the Programmer class and adds grossSales and commissionRate fields
 * and related methods.
 */
public class CommissionProgrammer extends Programmer {

	/**
	 * The total gross sales of the programmer
	 */
	private double grossSales;

	/**
	 * The commission rate earned by the programmer
	 */
	private double commissionRate;

	/**
	 * 
	 * Constructs a CommissionProgrammer object with the specified attributes.
	 * 
	 * @param firstName            the first name of the programmer
	 * 
	 * @param lastName             the last name of the programmer
	 * 
	 * @param socialSecurityNumber the social security number of the programmer
	 * 
	 * @param month                the birth month of the programmer
	 * 
	 * @param year                 the birth year of the programmer
	 * 
	 * @param grossSales           the total gross sales of the programmer
	 * 
	 * @param commissionRate       the commission rate earned by the programmer
	 * 
	 * @throws IllegalArgumentException if the commissionRate is not within the
	 *                                  valid range or if the grossSales is negative
	 */
	public CommissionProgrammer(String firstName, String lastName, String socialSecurityNumber, int month, int year,
			double grossSales, double commissionRate) {
		super(firstName, lastName, socialSecurityNumber);

		if (commissionRate <= 0.0 || commissionRate >= 1.0) {
			throw new IllegalArgumentException("Commission rate must be > 0.0 and < 1.0");
		}

		if (grossSales < 0.0) {
			throw new IllegalArgumentException("Gross sales must be >= 0.0");
		}

		this.grossSales = grossSales;
		this.commissionRate = commissionRate;
	}

	/**
	 * 
	 * Sets the gross sales of the programmer.
	 * 
	 * @param grossSales the new gross sales
	 * 
	 * @throws IllegalArgumentException if the grossSales is negative
	 */
	public void setGrossSales(double grossSales) {
		if (grossSales < 0.0) {
			throw new IllegalArgumentException("Gross sales must be >= 0.0");
		}

		this.grossSales = grossSales;
	}

	/**
	 * 
	 * Returns the gross sales of the programmer.
	 * 
	 * @return the gross sales
	 */
	public double getGrossSales() {
		return grossSales;
	}

	/**
	 * 
	 * Sets the commission rate of the programmer.
	 * 
	 * @param commissionRate the new commission rate
	 * 
	 * @throws IllegalArgumentException if the commissionRate is not within the
	 *                                  valid range
	 */
	public void setCommissionRate(double commissionRate) {
		if (commissionRate <= 0.0 || commissionRate >= 1.0) {
			throw new IllegalArgumentException("Commission rate must be > 0.0 and < 1.0");
		}

		this.commissionRate = commissionRate;
	}

	/**
	 * 
	 * Returns the commission rate of the programmer.
	 * 
	 * @return the commission rate
	 */
	public double getCommissionRate() {
		return commissionRate;
	}

	/**
	 * 
	 * Calculates and returns the commission earnings for the programmer. The
	 * earnings are the product of the gross sales and commission rate.
	 * 
	 * @return the commission earnings
	 */
	@Override
	public double earnings() {
		return getCommissionRate() * getGrossSales();
	}

	/**
	 * 
	 * Returns the payment amount for the programmer, which is equal to their
	 * earnings.
	 * 
	 * @return the payment amount
	 */
	@Override
	public double getPaymentAmount() {
		return earnings();
	}

	/**
	 * 
	 * Returns a string representation of the CommissionProgrammer object.
	 * 
	 * @return a string representation of the programmer
	 */
	@Override
	public String toString() {
		return String.format("%s " + super.toString() + "\n%s: $%,.2f; %s: %.2f", "commission", "gross sales",
				getGrossSales(), "commission rate", getCommissionRate());
	}

}
