/**
 * Student Name: Onur Onel
 * 
 * Lab Professor: 
 * 
 * Due Date: March 31, 2023 11:59 PM
 * 
 * Project Name: Lab06
 **/
/**
 * 
 * Represents a programmer who earns a base salary in addition to commission
 * based on their sales.
 * 
 * Extends the CommissionProgrammer class and adds a baseSalary field and
 * related methods.
 */
public class BasePlusCommissionProgrammer extends CommissionProgrammer {

	/**
	 * The base salary per week
	 */
	private double baseSalary;

	/**
	 * 
	 * Constructs a BasePlusCommissionProgrammer object with the specified
	 * attributes.
	 * 
	 * @param firstName            the first name of the programmer
	 * 
	 * @param lastName             the last name of the programmer
	 * 
	 * @param socialSecurityNumber the social security number of the programmer
	 * 
	 * @param month                the birth month of the programmer
	 * 
	 * @param year                 the birth year of the programmer
	 * 
	 * @param grossSales           the total gross sales of the programmer
	 * 
	 * @param commissionRate       the commission rate earned by the programmer
	 * 
	 * @param baseSalary           the base salary earned by the programmer
	 * 
	 * @throws IllegalArgumentException if the baseSalary is negative
	 */
	public BasePlusCommissionProgrammer(String firstName, String lastName, String socialSecurityNumber, int month,
			int year, double grossSales, double commissionRate, double baseSalary) {
		super(firstName, lastName, socialSecurityNumber, month, year, grossSales, commissionRate);

		if (baseSalary < 0.0) {
			throw new IllegalArgumentException("Base salary must be >= 0.0");
		}

		this.baseSalary = baseSalary;
	}

	/**
	 * 
	 * Sets the base salary of the programmer.
	 * 
	 * @param baseSalary the new base salary
	 * 
	 * @throws IllegalArgumentException if the baseSalary is negative
	 */
	public void setBaseSalary(double baseSalary) {
		if (baseSalary < 0.0) {
			throw new IllegalArgumentException("Base salary must be >= 0.0");
		}

		this.baseSalary = baseSalary;
	}

	/**
	 * 
	 * Returns the base salary of the programmer.
	 * 
	 * @return the base salary
	 */
	public double getBaseSalary() {
		return baseSalary;
	}

	/**
	 * 
	 * Calculates and returns the payment amount for the programmer. The payment
	 * amount is the sum of the base salary and commission earnings.
	 * 
	 * @return the payment amount
	 */
	@Override
	public double getPaymentAmount() {
		return getBaseSalary() + super.earnings();
	}

	/**
	 * 
	 * Returns a string representation of the BasePlusCommissionProgrammer object.
	 * 
	 * @return a string representation of the programmer
	 */
	@Override
	public String toString() {
		return String.format("%s%s", "Base-Plus",
				super.toString() + "; base salary;" + " " + formatCurrency(getBaseSalary()));
	}

	/**
	 * 
	 * Formats a currency amount to a string with the dollar sign and two decimal
	 * places.
	 * 
	 * @param amount the currency amount to format
	 * @return the formatted string
	 */
	private String formatCurrency(double amount) {
		return String.format("$%,.2f", amount);
	}
}