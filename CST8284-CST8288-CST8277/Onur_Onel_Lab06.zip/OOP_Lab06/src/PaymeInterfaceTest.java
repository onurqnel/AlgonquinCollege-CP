/**
 * Student Name: Onur Onel
 * 
 * Lab Professor: 
 * 
 * Due Date: March 31, 2023 11:59 PM
 * 
 * Project Name: Lab06
 **/
/**
 * 
 * A class for testing the Payme interface and the programmer classes.
 * 
 * Creates an array of Payme objects that includes invoices and different types
 * of programmers.
 * 
 * Calculates the payment due for each object using polymorphism.
 * 
 * Increases the base salary of BasePlusCommissionProgrammers by 10% if
 * applicable.
 */
public class PaymeInterfaceTest {
/**
 * 
 * @param args Main method args
 */
	public static void main(String[] args) {

		// Create an array of Payme objects
		Payme[] payments = new Payme[6];

		// Initialize the array with different objects
		payments[0] = new Invoice("22776", "brakes", 3, 300.00);
		payments[1] = new Invoice("33442", "gear", 5, 90.99);
		payments[2] = new HourlyProgrammer("Amara", "Chukwu", "234-56-7770", 6, 2023, 18.95, 40);
		payments[3] = new CommissionProgrammer("Peter", "Goodman", "123-45-6999", 3, 2023, 16500, 0.44);
		payments[4] = new SalariedProgrammer("Chioma", "Chidimma", "123-45-6789", 1, 2023, 320.00);
		payments[5] = new BasePlusCommissionProgrammer("Esther", "Patel", "102-34-5888", 5, 2023, 1200.00, 0.04, 720.0);

		System.out.println("Payment for Invoices and Programmers are processed polymorphically:\n");

		// Process the payment for each object using polymorphism
		for (Payme currentPayme : payments) {
			System.out.printf("%s \n", currentPayme.toString());

			// Increase the base salary of BasePlusCommissionProgrammers by 10% if
			// applicable
			if (currentPayme instanceof BasePlusCommissionProgrammer) {
				BasePlusCommissionProgrammer programmer = (BasePlusCommissionProgrammer) currentPayme;
				double oldBaseSalary = programmer.getBaseSalary();
				programmer.setBaseSalary(1.10 * oldBaseSalary);
				System.out.printf("New base salary with 10%% increase is: $%.2f\n", programmer.getBaseSalary());
			}

			// Calculate the payment due for the current object and display it
			System.out.printf("Payment due: $%.2f\n\n", currentPayme.getPaymentAmount());
		}
	}
}
