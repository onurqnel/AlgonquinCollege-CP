package w23assignment2;

/**
 * A class to test the {@link WorldClock} class.
 * @author Onur Onel
 * @version 1.0
 */
public class WorldClockDemo {

	/**
	 * The main method to run the WorldClock demo.
	 * 
	 * @param args command-line arguments (not used)
	 */
	public static void main(String[] args) {
		// test WorldClock
		System.out.println("Testing WorldClock class");
		int offset = 3;
		System.out.println("Offset: " + offset);
		WorldClock wclock = new WorldClock(0, 0, offset);
		System.out.println("Hours: " + (wclock.getHours() + offset));
		System.out.println("Minutes: " + wclock.getMinutes());
		System.out.println("Time: " + wclock.getTime());
	}

}
