package w23assignment2;

/**
 * A class to test the {@link Clock} class. 
 * @author Onur Onel
 * @version 1.0
 */
public class ClockDemo {

	/**
	 * The main method to run the Clock demo.
	 * 
	 * @param args command-line arguments (not used)
	 */
	public static void main(String[] args) {
		// test Clock
		System.out.println("Testing Clock class");
		Clock clock = new Clock(0, 0);
		System.out.println("Hours: " + clock.getHours());
		System.out.println("Minutes: " + clock.getMinutes());
		System.out.println("Time: " + clock.getTime());
	}

}
