package w23assignment2;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * The Clock class represents a clock that can return the current time at the
 * user's location.
 * 
 * @author Onur Onel
 * @version 1.0
 */
public class Clock {

	/**
	 * The current hours of the clock.
	 */
	private int hours;

	/**
	 * The current minutes of the clock.
	 */
	private int minutes;

	 /**
     * Constructs a new Clock object with the specified hours and minutes.
     *
     * @param hours the hours of the clock
     * @param minutes the minutes of the clock
     */
	public Clock(int hours, int minutes) {
		this.hours = hours;
		this.minutes = minutes;
	}

	/**
	 * Gets the hours of the clock.
	 * 
	 * @return The hours of the clock
	 */
	public int getHours() {
		LocalDateTime now = LocalDateTime.ofInstant(Instant.now(), ZoneId.systemDefault());
		this.hours = now.getHour();
		return hours;
	}

	/**
	 * Sets the hours of the clock.
	 * 
	 * @param hours The new hours of the clock
	 */
	public void setHours(int hours) {
		this.hours = hours;
	}

	/**
	 * Gets the minutes of the clock.
	 * 
	 * @return The minutes of the clock
	 */
	public int getMinutes() {
		LocalDateTime now = LocalDateTime.ofInstant(Instant.now(), ZoneId.systemDefault());
		this.minutes = now.getMinute();
		return minutes;
	}

	/**
	 * Sets the minutes of the clock.
	 * 
	 * @param minutes The new minutes of the clock
	 */
	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}

	/**
	 * Gets the current time at the user's location as a string in the format
	 * "HH:mm".
	 * 
	 * @return The current time as a string in the format
	 */
	public String getTime() {
		LocalDateTime now = LocalDateTime.ofInstant(Instant.now(), ZoneId.systemDefault());
		int hour = now.getHour();
		int minute = now.getMinute();
		String timeString = String.format("%02d:%02d", hour, minute);
		return timeString;
	}
}
