package w23assignment2;

/**
 * 
 * The ClocksDemo class is a simple program that tests the functionality of the
 * Clock, WorldClock, and AlarmClock classes.
 * 
 * @author Onur Onel
 * @version 1.0
 */
public class ClocksDemo {
	/**
	 * The main method of the program that creates instances of the Clock,
	 * WorldClock, and AlarmClock classes, stores them in an array of Clock type,
	 * and uses polymorphism to print out their current time.
	 *
	 * @param args An array of command-line arguments
	 */
	public static void main(String[] args) {
		System.out.println("Testing all clock classes");

		// Create a Clock, a WorldClock, and an AlarmClock
		Clock clock = new Clock(1, 2);
		WorldClock worldClock = new WorldClock(1, 2, 3);
		AlarmClock alarmClock = new AlarmClock(4, 5, 6, 7);
		alarmClock.setAlarm(8, 9);

		// Store all clocks in an array of Clock type
		Clock[] clocks = new Clock[] { clock, worldClock, alarmClock };

		for (Clock clck : clocks) {
			String className = clck.getClass().getSimpleName();
			String time = clck.getTime();

			System.out.println(className + ": " + time);
		}
	}

}
