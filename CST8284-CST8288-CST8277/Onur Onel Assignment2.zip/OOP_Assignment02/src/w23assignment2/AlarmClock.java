package w23assignment2;

/**
 * 
 * The AlarmClock class is a subclass of the Clock class that adds an alarm
 * feature to the clock.
 * 
 * The alarm can be set to a specific time, and if the current time matches the
 * alarm time, the clock will indicate that the alarm has gone off.
 * 
 * @author Onur Onel
 * @version 1.0
 **/
public class AlarmClock extends Clock {
	/**
	 * Alarm Hours of Alarm Clock
	 */
	private int alarmHours;
	/**
	 * Alarm Minutes of Alarm Clock
	 */
	private int alarmMinutes;

	/**
	 * Constructor for creating an AlarmClock object with specified time and alarm
	 * time.
	 * 
	 * @param hours        The hours of the clock
	 * @param minutes      The minutes of the clock
	 * @param alarmHours   The hours of the alarm
	 * @param alarmMinutes The minutes of the alarm
	 */
	public AlarmClock(int hours, int minutes, int alarmHours, int alarmMinutes) {
		super(hours, minutes);
		this.alarmHours = alarmHours;
		this.alarmMinutes = alarmMinutes;
	}

	/**
	 * Sets the alarm time to the specified hours and minutes.
	 * 
	 * @param hours   The hours of the alarm
	 * @param minutes The minutes of the alarm
	 */
	public void setAlarm(int hours, int minutes) {
		alarmHours = hours;
		alarmMinutes = minutes;
	}

	/**
	 * Returns the current time of the clock, and if the alarm has been set and the
	 * current time is equal to or later than the alarm time, adds the string
	 * "Alarm" to the end of the time string. If the alarm has gone off, it resets
	 * the alarm time to 0.
	 * 
	 * @return The current time of the clock with the string "Alarm" added if the
	 *         alarm has gone off
	 */
	public String getTime() {
		String currentTime = super.getTime();
		if (alarmHours != 0 && alarmMinutes != 0) {
			if (getHours() >= alarmHours && getMinutes() >= alarmMinutes) {
				alarmHours = 0;
				alarmMinutes = 0;
				return currentTime + " Alarm";
			}
		}
		return currentTime;
	}
}
