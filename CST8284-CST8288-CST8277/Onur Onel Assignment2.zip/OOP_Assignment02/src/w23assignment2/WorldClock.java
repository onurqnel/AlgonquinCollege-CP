package w23assignment2;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * The WorldClock class represents a clock that can return the current time in a
 * specified time offset from the Universal Time Clock (UTC).
 * 
 * The time offset is calculated based on the difference between the user's
 * local time and Coordinated Universal Time (UTC).
 * 
 * This class extends the Clock class and inherits its properties and methods.
 * 
 * @author Onur Onel
 * @version 1.0
 */
public class WorldClock extends Clock {

	/**
	 * The time offset represents the difference in hours between the user's local
	 * time and Coordinated Universal Time (UTC).
	 */
	private int timeOffset;

	/**
	 * 
	 * Constructor for creating a WorldClock object with a specified time offset.
	 * 
	 * @param hours      The hours of the clock
	 * @param minutes    The minutes of the clock
	 * @param timeOffset The time offset from the local time, in hours
	 */
	public WorldClock(int hours, int minutes, int timeOffset) {
		super(hours, minutes);
		this.timeOffset = timeOffset;
	}

	/**
	 * Gets the time offset of the WorldClock.
	 * 
	 * @return The time offset from UTC in hours
	 */
	public int getTimeOffset() {
		return timeOffset;
	}

	/**
	 * Sets the time offset of the WorldClock.
	 * 
	 * @param timeOffset The new time offset from UTC in hours
	 */
	public void setTimeOffset(int timeOffset) {
		this.timeOffset = timeOffset;
	}

	/**
	 * Gets the current time at the user's location, adjusted for the time offset
	 * from UTC, and returns it as a string in the format
	 * 
	 * @return The current time as a string in the format
	 */
	@Override
	public String getTime() {
		LocalDateTime now = LocalDateTime.ofInstant(Instant.now(), ZoneId.systemDefault());
		int hour = now.getHour() + timeOffset;
		int minute = now.getMinute();
		String timeString = String.format("%02d:%02d", hour, minute);
		return timeString;
	}
}
