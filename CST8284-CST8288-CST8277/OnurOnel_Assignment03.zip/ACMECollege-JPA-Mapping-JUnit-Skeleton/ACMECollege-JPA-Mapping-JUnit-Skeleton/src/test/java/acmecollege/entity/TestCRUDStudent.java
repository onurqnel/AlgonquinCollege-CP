package acmecollege.entity;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.comparesEqualTo;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import common.JUnitBase;

@TestMethodOrder(MethodOrderer.MethodName.class)
public class TestCRUDStudent extends JUnitBase {

	private EntityManager em;
	private EntityTransaction et;

	private static Student student;

	private static final String FIRST_NAME = "Onur";
	private static final String LAST_NAME = "Onel";

	@BeforeAll
	static void setupAllInit() {
		student = new Student();
		student.setFirstName(FIRST_NAME);
		student.setLastName(LAST_NAME);

	}

	@BeforeEach
	void setup() {
		em = getEntityManager();
		et = em.getTransaction();
	}

	@AfterEach
	void tearDown() {
		em.close();
	}

	@Test
	void test01_Empty() {

		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Long> query = builder.createQuery(Long.class);
		Root<Student> root = query.from(Student.class);
		query.select(builder.count(root));
		TypedQuery<Long> tq = em.createQuery(query);
		long result = tq.getSingleResult();

		assertThat(result, is(comparesEqualTo(0L)));
	}

	@Test
	void test02_Create() {
		et.begin();
		student = new Student();
		student.setFirstName("Onur");
		student.setLastName("Onel");
		em.persist(student);
		et.commit();

		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Long> query = builder.createQuery(Long.class);
		Root<Student> root = query.from(Student.class);
		query.select(builder.count(root));
		query.where(builder.equal(root.get(Student_.id), builder.parameter(Integer.class, "id")));
		TypedQuery<Long> tq = em.createQuery(query);
		tq.setParameter("id", student.getId());
		long result = tq.getSingleResult();
		assertThat(result, is(greaterThanOrEqualTo(1L)));
	}

	@Test
	void test03_CreateInvalid() {
		et.begin();
		Student student2 = new Student();
		assertThrows(PersistenceException.class, () -> em.persist(student2));
		et.commit();
	}

	@Test
	void test04_Read() {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Student> query = builder.createQuery(Student.class);
		Root<Student> root = query.from(Student.class);
		query.select(root);
		TypedQuery<Student> tq = em.createQuery(query);
		List<Student> students = tq.getResultList();

		assertThat(students, contains(equalTo(student)));
	}

	@Test
	void test06_Update() {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Student> query = builder.createQuery(Student.class);
		Root<Student> root = query.from(Student.class);
		query.select(root);
		query.where(builder.equal(root.get(Student_.id), builder.parameter(Integer.class, "id")));
		TypedQuery<Student> tq = em.createQuery(query);
		tq.setParameter("id", student.getId());
		Student returnedStudent = tq.getSingleResult();

		String newFirstName = "Lebron";
		String newLastName = "James";

		et.begin();
		returnedStudent.setFirstName(newFirstName);
		returnedStudent.setLastName(newLastName);

		em.merge(returnedStudent);
		et.commit();

		returnedStudent = tq.getSingleResult();

		assertThat(returnedStudent.getFirstName(), equalTo(newFirstName));
		assertThat(returnedStudent.getLastName(), equalTo(newLastName));

	}

	@Test
	void test09_Delete() {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Student> query = builder.createQuery(Student.class);
		Root<Student> root = query.from(Student.class);
		query.select(root);
		query.where(builder.equal(root.get(Student_.id), builder.parameter(Integer.class, "id")));
		TypedQuery<Student> tq = em.createQuery(query);
		tq.setParameter("id", student.getId());
		Student returnedStudent = tq.getSingleResult();

		et.begin();
		Student student2 = new Student();
		student2.setFirstName("Onur");
		student2.setLastName("Onel");

		em.persist(student2);
		et.commit();

		et.begin();
		em.remove(returnedStudent);
		et.commit();

		CriteriaQuery<Long> query2 = builder.createQuery(Long.class);
		Root<Student> root2 = query2.from(Student.class);
		query2.select(builder.count(root2));
		query2.where(builder.equal(root2.get(Student_.id), builder.parameter(Integer.class, "id")));
		TypedQuery<Long> tq2 = em.createQuery(query2);
		tq2.setParameter("id", returnedStudent.getId());
		long result = tq2.getSingleResult();
		assertThat(result, is(equalTo(0L)));

		TypedQuery<Long> tq3 = em.createQuery(query2);
		tq3.setParameter("id", student2.getId());
		result = tq3.getSingleResult();
		assertThat(result, is(equalTo(1L)));
	}
}
