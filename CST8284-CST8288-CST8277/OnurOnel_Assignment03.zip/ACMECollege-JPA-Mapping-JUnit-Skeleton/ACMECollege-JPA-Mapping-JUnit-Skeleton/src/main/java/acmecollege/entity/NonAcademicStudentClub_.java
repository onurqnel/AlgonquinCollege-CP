package acmecollege.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2023-11-19T18:48:48.630-0500")
@StaticMetamodel(NonAcademicStudentClub.class)
public class NonAcademicStudentClub_ extends StudentClub_ {
}
