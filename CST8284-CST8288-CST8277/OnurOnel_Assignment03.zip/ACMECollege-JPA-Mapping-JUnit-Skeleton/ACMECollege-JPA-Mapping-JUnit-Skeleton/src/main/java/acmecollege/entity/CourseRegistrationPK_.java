package acmecollege.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2023-11-19T18:13:57.420-0500")
@StaticMetamodel(CourseRegistrationPK.class)
public class CourseRegistrationPK_ {
	public static volatile SingularAttribute<CourseRegistrationPK, Integer> studentId;
	public static volatile SingularAttribute<CourseRegistrationPK, Integer> courseId;
}
