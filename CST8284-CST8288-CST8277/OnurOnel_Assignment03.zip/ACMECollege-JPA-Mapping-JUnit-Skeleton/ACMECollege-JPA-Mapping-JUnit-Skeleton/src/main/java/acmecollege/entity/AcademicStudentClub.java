package acmecollege.entity;

import java.io.Serializable;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Table;

@Table(name = "student_club")
@DiscriminatorColumn(name = "academic")
@DiscriminatorValue("1")
public class AcademicStudentClub extends StudentClub implements Serializable {
	private static final long serialVersionUID = 1L;

	public AcademicStudentClub() {
	}
}
