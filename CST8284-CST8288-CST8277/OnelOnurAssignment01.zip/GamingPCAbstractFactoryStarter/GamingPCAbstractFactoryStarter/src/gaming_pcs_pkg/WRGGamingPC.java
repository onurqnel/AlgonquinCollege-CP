/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package gaming_pcs_pkg;

import gaming_pc_factories_pkg.GamingPCFactory;

/**
 * The WRGGamingPC class represents a gaming PC model called "WRG Gaming PC"
 * that can be equipped with various components using a GamingPCFactory.
 *
 * @author onurqnel
 */
public class WRGGamingPC extends GamingPC {

    GamingPCFactory theGamingPCFactory;

    /**
     * Constructs a WRGGamingPC object with the specified GamingPCFactory.
     *
     * @param theGamingPCFactory the factory used to create the components for
     * the gaming PC
     */
    public WRGGamingPC(GamingPCFactory theGamingPCFactory) {
        this.theGamingPCFactory = theGamingPCFactory;
    }

    /**
     * Equips the WRG Gaming PC with components using the specified
     * GamingPCFactory. This method creates the CPU, RAM, storage, and graphics
     * adapter components for the gaming PC.
     */
    @Override
    public void equipGamingPC() {
        System.out.println("Adding components to WRG Gaming PC " + getName());
        this.cpu = theGamingPCFactory.createCPU();
        this.ram = theGamingPCFactory.createRAM();
        this.storage = theGamingPCFactory.createStorage();
        this.graphicsAdapter = theGamingPCFactory.createGraphicsAdapter();
    }

}
