/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package gaming_pcs_pkg;

import gaming_pc_factories_pkg.GamingPCFactory;

/**
 * The G4LGamingPC class represents a gaming PC model called "G4L Gaming PC"
 * that can be equipped with various components using a GamingPCFactory.
 *
 * It extends the abstract class GamingPC and implements the equipGamingPC
 * method to define how the components are created and assigned to the G4L
 * Gaming PC.
 *
 * The class has a field to store the GamingPCFactory used to create the
 * components.
 *
 * @author onurqnel
 */
public class G4LGamingPC extends GamingPC {

    GamingPCFactory theGamingPCFactory;

    /**
     * Constructs a G4LGamingPC object with the specified GamingPCFactory.
     *
     * @param theGamingPCFactory the factory used to create the components for
     * the gaming PC
     */
    public G4LGamingPC(GamingPCFactory theGamingPCFactory) {
        this.theGamingPCFactory = theGamingPCFactory;
    }

    /**
     * Equips the G4L Gaming PC with components using the specified
     * GamingPCFactory. This method creates the CPU, RAM, storage, and graphics
     * adapter components for the gaming PC.
     */
    @Override
    public void equipGamingPC() {
        System.out.println("Adding components to G4L Gaming PC " + getName());

        cpu = theGamingPCFactory.createCPU();
        ram = theGamingPCFactory.createRAM();
        storage = theGamingPCFactory.createStorage();
        graphicsAdapter = theGamingPCFactory.createGraphicsAdapter();
    }

}
