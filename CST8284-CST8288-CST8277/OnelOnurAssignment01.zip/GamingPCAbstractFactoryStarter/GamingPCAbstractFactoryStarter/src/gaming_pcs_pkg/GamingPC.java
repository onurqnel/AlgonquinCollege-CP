/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package gaming_pcs_pkg;

import gaming_pc_components_pkg.CPU;
import gaming_pc_components_pkg.GraphicsAdapter;
import gaming_pc_components_pkg.RAM;
import gaming_pc_components_pkg.Storage;

/**
 * The GamingPC class represents a gaming PC and provides methods to equip the
 * PC with components, display information about the components, and get a
 * string representation of the PC. It is an abstract class, and specific gaming
 * PC models should extend this class.
 *
 * The class defines objects that represent the CPU, RAM, storage, and graphics
 * adapter of the gaming PC. These objects can be changed easily by assigning
 * new parts in specific GamingPCFactory implementations.
 *
 * It also provides a name for the gaming PC and methods to get and set the
 * name.
 *
 * @author onurqnel
 */
public abstract class GamingPC {

    private String name;

    // Newly defined objects that represent the CPU, RAM, storage, & graphics adapter.
    // These can be changed easily by assigning new parts 
    // in specific GamingPCFactory implementations.
    protected CPU cpu;
    protected RAM ram;
    protected Storage storage;
    protected GraphicsAdapter graphicsAdapter;

    /**
     * Gets the name of the gaming PC.
     *
     * @return the name of the gaming PC
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the gaming PC.
     *
     * @param name the name of the gaming PC
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Abstract method to equip the gaming PC with components. Each specific
     * gaming PC model should implement this method to define how the components
     * are created and assigned to the PC.
     */
    public abstract void equipGamingPC();

    /**
     * Displays information about the CPU component of the gaming PC.
     */
    public void displayCPUInfo() {
        System.out.println(getName() + " CPU:  " + cpu);
    }

    /**
     * Displays information about the RAM component of the gaming PC.
     */
    public void displayRAMInfo() {
        System.out.println(getName() + " RAM:  " + ram);
    }

    /**
     * Displays information about the storage component of the gaming PC.
     */
    public void displayStorageInfo() {
        System.out.println(getName() + " Storage:  " + storage);
    }

    /**
     * Displays information about the graphics adapter component of the gaming
     * PC.
     */
    public void displayGraphicsAdapterInfo() {
        System.out.println(getName() + " Graphics Adapter:  " + graphicsAdapter);
    }

    /**
     * Returns a string representation of the gaming PC.
     *
     * @return a string representation of the gaming PC
     */
    @Override
    public String toString() {
        String gamingPCInfo = "The " + getName() + " has\n\t" + cpu + ",\n\t"
                + ram + ",\n\t" + storage + " , and\n\t" + graphicsAdapter;
        return gamingPCInfo;
    }

}
