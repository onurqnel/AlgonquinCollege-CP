/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package gaming_pc_factories_pkg;

import gaming_pc_components_pkg.CPU;
import gaming_pc_components_pkg.G4LCPU;
import gaming_pc_components_pkg.G4LGraphicsAdapter;
import gaming_pc_components_pkg.G4LRAM;
import gaming_pc_components_pkg.G4LStorage;
import gaming_pc_components_pkg.GraphicsAdapter;
import gaming_pc_components_pkg.RAM;
import gaming_pc_components_pkg.Storage;

/**
 * The G4LGamingPCFactory class is an implementation of the GamingPCFactory
 * interface. It defines the components used for the G4L gaming PC by
 * implementing the methods from the interface.
 *
 * The class provides methods to create specific CPU, RAM, storage, and graphics
 * adapter objects that will be associated with the G4L gaming PC.
 *
 * The returned objects from each method specify the specific components used
 * for the G4L gaming PC.
 *
 * This factory class is responsible for creating G4L gaming PC components.
 *
 * It implements the GamingPCFactory interface, which defines the blueprint for
 * creating gaming PC components.
 *
 * By implementing this factory class, it allows for the creation of G4L gaming
 * PCs with specific component configurations.
 *
 * The G4LGamingPCFactory class is part of a factory design pattern that enables
 * flexibility and modularity in creating different gaming PC models.
 *
 * This class follows the Factory Method design pattern, which encapsulates the
 * object creation logic and delegates the actual creation of objects to the
 * factory class.
 *
 * The G4LGamingPCFactory class ensures that the creation of G4L gaming PC
 * components is centralized and separate from the client code that uses the
 * components.
 *
 * This class serves as a factory for creating G4L gaming PC components.
 *
 * @author onurqnel
 */
public class G4LGamingPCFactory implements GamingPCFactory {

    /**
     * Creates a CPU object for the G4L gaming PC.
     *
     * @return a CPU object for the G4L gaming PC
     */
    @Override
    public CPU createCPU() {
        return new G4LCPU();
    }

    /**
     * Creates a RAM object for the G4L gaming PC.
     *
     * @return a RAM object for the G4L gaming PC
     */
    @Override
    public RAM createRAM() {
        return new G4LRAM();
    }

    /**
     * Creates a Storage object for the G4L gaming PC.
     *
     * @return a Storage object for the G4L gaming PC
     */
    @Override
    public Storage createStorage() {
        return new G4LStorage();
    }

    /**
     * Creates a GraphicsAdapter object for the G4L gaming PC.
     *
     * @return a GraphicsAdapter object for the G4L gaming PC
     */
    @Override
    public GraphicsAdapter createGraphicsAdapter() {
        return new G4LGraphicsAdapter();
    }

}
