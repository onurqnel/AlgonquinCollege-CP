/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package gaming_pc_factories_pkg;

import gaming_pc_components_pkg.CPU;
import gaming_pc_components_pkg.GraphicsAdapter;
import gaming_pc_components_pkg.RAM;
import gaming_pc_components_pkg.Storage;
import gaming_pc_components_pkg.WRGCPU;
import gaming_pc_components_pkg.WRGGraphicsAdapter;
import gaming_pc_components_pkg.WRGRAM;
import gaming_pc_components_pkg.WRGStorage;

/**
 * The WRGGamingPCFactory class is an implementation of the GamingPCFactory
 * interface. It defines the components used for the WRG gaming PC by
 * implementing the methods from the interface.
 *
 * The class provides methods to create specific CPU, RAM, storage, and graphics
 * adapter objects that will be associated with the WRG gaming PC.
 *
 * The returned objects from each method specify the specific components used
 * for the WRG gaming PC.
 *
 * @author onurqnel
 */
public class WRGGamingPCFactory implements GamingPCFactory {

    /**
     * Creates a CPU object associated with the WRG gaming PC.
     *
     * @return a CPU object for the WRG gaming PC
     */
    @Override
    public CPU createCPU() {
        return new WRGCPU();
    }

    /**
     * Creates a RAM object associated with the WRG gaming PC.
     *
     * @return a RAM object for the WRG gaming PC
     */
    @Override
    public RAM createRAM() {
        return new WRGRAM();
    }

    /**
     * Creates a Storage object associated with the WRG gaming PC.
     *
     * @return a Storage object for the WRG gaming PC
     */
    @Override
    public Storage createStorage() {
        return new WRGStorage();
    }

    /**
     * Creates a GraphicsAdapter object associated with the WRG gaming PC.
     *
     * @return a GraphicsAdapter object for the WRG gaming PC
     */
    @Override
    public GraphicsAdapter createGraphicsAdapter() {
        return new WRGGraphicsAdapter();
    }

}
