/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package gaming_pc_factories_pkg;

import gaming_pc_components_pkg.CPU;
import gaming_pc_components_pkg.GraphicsAdapter;
import gaming_pc_components_pkg.RAM;
import gaming_pc_components_pkg.Storage;

/**
 * The GamingPCFactory interface defines the methods that need to be implemented
 * by a specific gaming PC factory.
 *
 * It declares methods for creating CPU, RAM, storage, and graphics adapter
 * objects. Each method should be implemented by a factory class to specify the
 * creation of the corresponding component for a specific gaming PC model.
 *
 * The implementing factory classes will provide the actual logic for creating
 * the components and associating them with a gaming PC model.
 *
 * By defining this interface, it allows for the creation of different gaming PC
 * models with different component configurations by using different factory
 * implementations.
 *
 * This interface serves as a blueprint for the factory classes that create
 * gaming PC components.
 *
 * @author onurqnel
 */
public interface GamingPCFactory {

    /**
     * Creates a CPU object for a specific gaming PC model.
     *
     * @return a CPU object
     */
    public CPU createCPU();

    /**
     * Creates a RAM object for a specific gaming PC model.
     *
     * @return a RAM object
     */
    public RAM createRAM();

    /**
     * Creates a Storage object for a specific gaming PC model.
     *
     * @return a Storage object
     */
    public Storage createStorage();

    /**
     * Creates a GraphicsAdapter object for a specific gaming PC model.
     *
     * @return a GraphicsAdapter object
     */
    public GraphicsAdapter createGraphicsAdapter();

}
