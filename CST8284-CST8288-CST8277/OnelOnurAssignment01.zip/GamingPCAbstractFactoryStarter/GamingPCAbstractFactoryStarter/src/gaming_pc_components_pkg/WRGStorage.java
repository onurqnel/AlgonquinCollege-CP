/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package gaming_pc_components_pkg;

/**
 * The WRGStorage class represents a storage component for the WRG gaming PC
 * model. It implements the Storage interface and provides the information about
 * the storage component.
 *
 * The class defines a specific storage configuration for the WRG gaming PC,
 * which is a 500 GB M.2 NVMe drive.
 *
 * The toString() method is overridden to provide a string representation of the
 * storage component.
 *
 * This class represents the storage component specifically designed for the WRG
 * gaming PC.
 *
 * It is part of the gaming_pc_components_pkg package, which contains the
 * components used in gaming PCs.

 * @author onurqnel
 */
public class WRGStorage implements Storage {

    private String info = "500 GB M.2 NVMe";

    /**
     * Returns a string representation of the WRG storage component.
     *
     * @return a string representation of the WRG storage component
     */
    @Override
    public String toString() {
        return info;
    }
}
