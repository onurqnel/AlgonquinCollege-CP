/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package gaming_pc_components_pkg;

/**
 * The G4LRAM class represents a RAM component for the G4L gaming PC model. It
 * implements the RAM interface and provides the information about the RAM
 * component.
 *
 * The class defines a specific RAM configuration for the G4L gaming PC, which
 * is 8GB DDR4.
 *
 * The toString() method is overridden to provide a string representation of the
 * RAM component.
 *
 * This class represents the RAM component specifically designed for the G4L
 * gaming PC.
 *
 * It is part of the gaming_pc_components_pkg package, which contains the
 * components used in gaming PCs.
 *
 * @author onurqnel
 */
public class G4LRAM implements RAM {

    private String info = "8GB DDR4";

    /**
     * Returns a string representation of the G4L RAM component.
     *
     * @return a string representation of the G4L RAM component
     */
    @Override
    public String toString() {
        return info;
    }
}
