/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package gaming_pc_components_pkg;

/**
 * The WRGCPU class represents a CPU component for the WRG gaming PC model. It
 * implements the CPU interface and provides the information about the CPU
 * component.
 *
 * The class defines a specific CPU configuration for the WRG gaming PC, which
 * is WRG Core i5-12400F 6P+0EC/12T processor running at 2.5-4.4 GHz with 18MB
 * cache.
 *
 * The toString() method is overridden to provide a string representation of the
 * CPU component.
 *
 * This class represents the CPU component specifically designed for the WRG
 * gaming PC.
 *
 * It is part of the gaming_pc_components_pkg package, which contains the
 * components used in gaming PCs.
 *
 * @author onurqnel
 */
public class WRGCPU implements CPU {

    private String info = "WRG Core i5-12400F 6P+0EC/12T 2.5-4.4 GHz 18MB Cache processor";

    /**
     * Returns a string representation of the WRG CPU component.
     *
     * @return a string representation of the WRG CPU component
     */
    @Override
    public String toString() {
        return info;
    }
}
