/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package gaming_pc_components_pkg;

/**
 * The G4LStorage class represents a storage component for the G4L gaming PC
 * model. It implements the Storage interface and provides the information about
 * the storage component.
 *
 * The class defines a specific storage configuration for the G4L gaming PC,
 * which is a 512GB PCIe Solid State Drive.
 *
 * The toString() method is overridden to provide a string representation of the
 * storage component.
 *
 * This class represents the storage component specifically designed for the G4L
 * gaming PC.
 *
 * It is part of the gaming_pc_components_pkg package, which contains the
 * components used in gaming PCs.
 * 
 * @author onurqnel
 */
public class G4LStorage implements Storage {

    private String info = "512GB PCIe Solid State Drive storage";

    /**
     * Returns a string representation of the G4L storage component.
     *
     * @return a string representation of the G4L storage component
     */
    @Override
    public String toString() {
        return info;
    }
}
