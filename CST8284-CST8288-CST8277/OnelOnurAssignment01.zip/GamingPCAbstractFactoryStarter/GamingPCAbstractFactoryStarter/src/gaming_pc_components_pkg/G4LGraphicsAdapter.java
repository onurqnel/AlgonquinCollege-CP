/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package gaming_pc_components_pkg;

/**
 * The G4LGraphicsAdapter class represents a graphics adapter component for the
 * G4L gaming PC model. It implements the GraphicsAdapter interface and provides
 * the information about the graphics adapter component.
 *
 * The class defines a specific graphics adapter configuration for the G4L
 * gaming PC, which is G4L GTX1650S with 4GB DDR6 memory.
 *
 * The toString() method is overridden to provide a string representation of the
 * graphics adapter component.
 *
 * This class represents the graphics adapter component specifically designed
 * for the G4L gaming PC.
 *
 * It is part of the gaming_pc_components_pkg package, which contains the
 * components used in gaming PCs.
 *
 * @author onurqnel
 */
public class G4LGraphicsAdapter implements GraphicsAdapter {

    private String info = "G4L GTX1650S 4GB DDR6 graphics";

    /**
     * Returns a string representation of the G4L graphics adapter component.
     *
     * @return a string representation of the G4L graphics adapter component
     */
    @Override
    public String toString() {
        return info;
    }
}
