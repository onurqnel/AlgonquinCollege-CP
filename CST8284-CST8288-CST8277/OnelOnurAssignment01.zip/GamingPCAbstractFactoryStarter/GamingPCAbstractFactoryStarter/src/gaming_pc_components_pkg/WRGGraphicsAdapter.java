/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package gaming_pc_components_pkg;

/**
 * The WRGGraphicsAdapter class represents a graphics adapter component for the
 * WRG gaming PC model. It implements the GraphicsAdapter interface and provides
 * the information about the graphics adapter component.
 *
 * The class defines a specific graphics adapter configuration for the WRG
 * gaming PC, which is WRG RTX 3050 with 8GB GDDR6 memory and a 128-bit memory
 * interface.
 *
 * The toString() method is overridden to provide a string representation of the
 * graphics adapter component.
 *
 * This class represents the graphics adapter component specifically designed
 * for the WRG gaming PC.
 *
 * It is part of the gaming_pc_components_pkg package, which contains the
 * components used in gaming PCs.
 *
 * @author onurqnel
 */
public class WRGGraphicsAdapter implements GraphicsAdapter {

    private String info = "WRG RTX 3050 8GB GDDR6 128-bit";

    /**
     * Returns a string representation of the WRG graphics adapter component.
     *
     * @return a string representation of the WRG graphics adapter component
     */
    @Override
    public String toString() {
        return info;
    }
}
