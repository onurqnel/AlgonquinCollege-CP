/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package gaming_pc_components_pkg;

/**
 * The G4LCPU class represents a CPU component for the G4L gaming PC model. It
 * implements the CPU interface and provides the information about the CPU
 * component.
 *
 * The class defines a specific CPU configuration for the G4L gaming PC, which
 * is a 2.6GHz G4L Core i5-11400F processor.
 *
 * The toString() method is overridden to provide a string representation of the
 * CPU component.
 *
 * This class represents the CPU component specifically designed for the G4L
 * gaming PC.
 *
 * It is part of the gaming_pc_components_pkg package, which contains the
 * components used in gaming PCs.
 *
 * @author onurqnel
 */
public class G4LCPU implements CPU {

    private String info = "2.6GHz G4L Core i5-11400F processor";

    /**
     * Returns a string representation of the G4L CPU component.
     *
     * @return a string representation of the G4L CPU component
     */
    @Override
    public String toString() {
        return info;
    }
}
