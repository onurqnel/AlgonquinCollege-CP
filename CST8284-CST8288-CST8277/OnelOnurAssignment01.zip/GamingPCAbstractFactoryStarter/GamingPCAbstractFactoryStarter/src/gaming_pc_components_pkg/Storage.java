/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package gaming_pc_components_pkg;

/**
 * The Storage interface represents a storage component for a gaming PC. Any
 * class that implements this interface can be used as a storage component in a
 * gaming PC.
 *
 * The interface provides a contract for implementing classes to define the
 * behavior of the storage component, specifically the toString() method for
 * getting a string representation of the storage.
 *
 * Implementing classes should override the toString() method to provide the
 * specific details of the storage component.
 *
 * This interface allows for flexibility in choosing different storage
 * components for different gaming PC models.
 *
 * It is part of the gaming_pc_components_pkg package, which contains the
 * components used in gaming PCs.
 *
 * @author onurqnel
 */
public interface Storage {

    /**
     * Returns a string representation of the storage component.
     *
     * @return a string representation of the storage component
     */
    @Override
    public String toString();

}
