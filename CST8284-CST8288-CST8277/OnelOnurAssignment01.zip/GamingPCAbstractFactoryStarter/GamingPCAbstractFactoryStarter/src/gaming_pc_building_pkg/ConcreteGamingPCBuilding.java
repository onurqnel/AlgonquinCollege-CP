/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package gaming_pc_building_pkg;

import gaming_pc_factories_pkg.G4LGamingPCFactory;
import gaming_pc_factories_pkg.WRGGamingPCFactory;
import gaming_pcs_pkg.G4LGamingPC;
import gaming_pcs_pkg.GamingPC;
import gaming_pcs_pkg.WRGGamingPC;
import gaming_pc_factories_pkg.GamingPCFactory;

/**
 * The ConcreteGamingPCBuilding class is a subclass of GamingPCBuilding that
 * represents a concrete implementation of the gaming PC building process. It
 * overrides the makeGamingPC() method to create specific types of gaming PCs
 * using corresponding factories.
 *
 * This class specifically supports creating G4L and WRG gaming PCs.
 *
 * It is part of the gaming_pc_building_pkg package, which contains the classes
 * related to building gaming PCs.
 *
 * @author onurqnel
 */
public class ConcreteGamingPCBuilding extends GamingPCBuilding {

    /**
     * Creates a gaming PC of the specified type using the corresponding
     * factory.
     *
     * @param typeOfGamingPC the type of gaming PC to create
     * @return the constructed gaming PC
     */
    @Override
    protected GamingPC makeGamingPC(String typeOfGamingPC) {
        GamingPC theGamingPC = null;
        if ("G4L".equalsIgnoreCase(typeOfGamingPC)) {
            GamingPCFactory theGamingPCFactory = new G4LGamingPCFactory();
            theGamingPC = new G4LGamingPC(theGamingPCFactory);
            theGamingPC.setName("G4L G15CE-RI516S-CA Gaming Desktop");
            System.out.println("Created G4L Gaming PC " + theGamingPC.getName());
        } else if ("WRG".equalsIgnoreCase(typeOfGamingPC)) {
            GamingPCFactory theGamingPCFactory = new WRGGamingPCFactory();
            theGamingPC = new WRGGamingPC(theGamingPCFactory);
            theGamingPC.setName("WRG Codex SE 12TH-054CA Gaming Desktop Computer");
            System.out.println("Created WRG Gaming PC " + theGamingPC.getName());
        }
        return theGamingPC;
    }
}
