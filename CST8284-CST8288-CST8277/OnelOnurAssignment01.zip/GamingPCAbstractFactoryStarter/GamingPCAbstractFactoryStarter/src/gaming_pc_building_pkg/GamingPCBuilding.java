/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package gaming_pc_building_pkg;

import gaming_pcs_pkg.GamingPC;

/**
 * The GamingPCBuilding class is an abstract class that represents the building
 * process for gaming PCs. It provides a template for constructing different
 * types of gaming PCs.
 *
 * Subclasses of GamingPCBuilding should implement the makeGamingPC() method to
 * create a specific type of gaming PC.
 *
 * The orderTheGamingPC() method is a high-level method that uses the template
 * defined by the abstract class to build and equip a gaming PC of a specified
 * type.
 *
 * It is part of the gaming_pc_building_pkg package, which contains the classes
 * related to building gaming PCs.
 *
 * @author onurqnel
 */
public abstract class GamingPCBuilding {

    /**
     * Creates a gaming PC of the specified type.
     *
     * @param typeOfGamingPC the type of gaming PC to create
     * @return the constructed gaming PC
     */
    protected abstract GamingPC makeGamingPC(String typeOfGamingPC);

    /**
     * Orders a gaming PC of the specified type and equips it with components.
     *
     * @param typeOfGamingPC the type of gaming PC to order
     * @return the ordered and equipped gaming PC
     */
    public GamingPC orderTheGamingPC(String typeOfGamingPC) {
        GamingPC theGamingPC = makeGamingPC(typeOfGamingPC);
        theGamingPC.equipGamingPC();
        return theGamingPC;
    }

}
