package gaming_pc_main_pkg;
import gaming_pc_building_pkg.ConcreteGamingPCBuilding;
import gaming_pc_building_pkg.GamingPCBuilding;
import gaming_pcs_pkg.GamingPC;

/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 *
package gaming_pc_main_pkg;

import gaming_pc_building_pkg.ConcreteGamingPCBuilding;
import gaming_pc_building_pkg.GamingPCBuilding;
import gaming_pcs_pkg.GamingPC;

/**
 * The GamingPCFactoryTest class is a test class that demonstrates the usage of
 * the GamingPCBuilding and GamingPC classes to create and display information
 * about different gaming PC models.
 *
 * It creates an instance of ConcreteGamingPCBuilding, which is an
 * implementation of the GamingPCBuilding interface. Then, it uses the
 * GamingPCBuilding object to order and display information about two gaming PC
 * models: G4L and WRG.
 *
 * This class serves as an entry point for running the test program.
 *
 * @author onurqnel
 */
public class GamingPCFactoryTest {

    /**
     * The main method is the entry point for running the test program. It
     * creates an instance of ConcreteGamingPCBuilding, orders the G4L and WRG
     * gaming PC models, and displays information about the components of each
     * PC.
     *
     * @param args the command line arguments (not used in this program)
     */
    public static void main(String[] args) {

        GamingPCBuilding theGamingPCBuilding = new ConcreteGamingPCBuilding();

        GamingPC theG4LGamingPC = theGamingPCBuilding.orderTheGamingPC("G4L");
        theG4LGamingPC.displayCPUInfo();
        theG4LGamingPC.displayRAMInfo();
        theG4LGamingPC.displayStorageInfo();
        theG4LGamingPC.displayGraphicsAdapterInfo();
        System.out.println(theG4LGamingPC + "\n");

        GamingPC theWRGGamingPC = theGamingPCBuilding.orderTheGamingPC("WRG");
        theWRGGamingPC.displayCPUInfo();
        theWRGGamingPC.displayRAMInfo();
        theWRGGamingPC.displayStorageInfo();
        theWRGGamingPC.displayGraphicsAdapterInfo();
        System.out.println(theWRGGamingPC + "\n");

    }

}
