/* 
 * File name: OOP_Lab01 
 * Author: Onur Onel, 041074824
 * Course: CST8132 – OOP
 * Assignment: Lab 01
 * Date: 17.01.2023
 * Professor: George Kriger
 * Purpose: This program gets user information inputs from the user (first name, last name and student number).
 * Class list: Username.java, Driver.java
 */

/**
 * @author Onur Onel
 * @version 1.0
 * @since javac 17.0.4.1
 */
public class Username {
	/**
	 * These three variables represent the user's name, surname, and student number.
	 */
	private String firstName;
	private String lastName;
	private long studentNumber;

	/**
	 * Username is a public class constructor.
	 */
	public Username() {

	}

	/**
	 * The class has a default constructor and a constructor that takes in a user's
	 * first name, last name, and student number as parameters.
	 * 
	 * @param firstName     parameter specifies the first name of the user.
	 * @param lastName      parameter specifies the surname of the user.
	 * @param studentNumber parameter specifies the student number of user.
	 */
	public Username(String firstName, String lastName, long studentNumber) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.studentNumber = studentNumber;
	}

	/**
	 * The class also has getter and setter methods for each of the fields (first
	 * name, last name, and student number) that allow for the retrieval and
	 * modification of the values.
	 * 
	 * This method gets first name of the user.
	 * 
	 * @return Returns String object called firstName.
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * This method sets the FirstName given name from the user.
	 * 
	 * @param firstName is String object of this set method.
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * This method gets surname of the user.
	 * 
	 * @return Returns String object called lastName.
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * This method sets the LastName given surname from the user.
	 * 
	 * @param lastName is String object of this set method.
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * This methods gets student number of the user.
	 * 
	 * @return Returns long object called studentNumber.
	 */
	public long getStudentNumber() {
		return studentNumber;
	}

	/**
	 * This method sets the StudentNumber given number from the user.
	 * 
	 * @param studentNumber is String object of this set method.
	 */
	public void setStudentNumber(long studentNumber) {
		this.studentNumber = studentNumber;

	}

	/**
	 * This is a method that generates a user ID based on a student's first name,
	 * last name, and student number.
	 * 
	 * @return The method concatenates the truncated first name, last name, and
	 *         student number, and returns the resulting string as the user ID.
	 */
	public String userIdGenerator() {

		String LowerName = firstName.toLowerCase(); // Converts the first name and last name to lowercase.
		String LowerSurname = lastName.toLowerCase();
		String clearName = LowerName.trim().toLowerCase();// Removes any leading or trailing whitespace.
		String clearSurname = LowerSurname.trim().toLowerCase();
		String clearNum = Long.toString(studentNumber); // Converts the student number to a string.

		if (clearName.length() > 4) {
			clearName = clearName.substring(0, 3); // Truncates them to at most 3 characters.

		}
		if (clearSurname.length() > 3) {
			clearSurname = clearSurname.substring(0, 3);// Truncates them to at most 3 characters.

		}
		if (clearNum.length() == 8) {
			clearNum = clearNum.substring(5, 8);// Truncates it to the last 3 digits if it's 8 digits long.

		} else {
			clearNum = "000";// If the student number isn't 8 digits long, it sets it to "000".
		}

		return clearName + clearSurname + clearNum;

	}
}
