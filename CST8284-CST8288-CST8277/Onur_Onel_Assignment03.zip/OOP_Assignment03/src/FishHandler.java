/**
 * FishHandler is a class to demonstrate exception handling and rethrowing in
 * Java.
 */
public class FishHandler {

	/**
	 * The main method initiates a call to easterStarting() and catches the rethrown
	 * exception.
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		try {
			easterStarting();
		} catch (Exception exception) {
			System.err.println("Caught exception in main: " + exception.getMessage());
			exception.printStackTrace();
		}
	}

	/**
	 * The easterEnding() method throws an Exception.
	 * 
	 * @throws Exception indicating an error in the easterEnding method
	 */
	public static void easterEnding() throws Exception {
		throw new Exception("Exception in easterEnding method");
	}

	/**
	 * The easterStarting() method calls easterEnding(), catches the Exception and
	 * rethrows it.
	 * 
	 * @throws Exception that was caught and rethrown from the easterEnding method
	 */
	public static void easterStarting() throws Exception {
		try {
			easterEnding();
		} catch (Exception exception) {
			System.err.println("Caught exception in easterStarting: " + exception.getMessage());
			throw exception;
		}
	}
}
