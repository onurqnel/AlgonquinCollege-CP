/**
 * 
 * This class demonstrates how to use try-catch blocks to handle exceptions in
 * Java.
 * 
 * It defines three custom exception classes that extend from ExceptionAlpha and
 * 
 * shows how to catch them using a catch block of type ExceptionAlpha.
 */
public class CatHandler {

	/**
	 * 
	 * The main method creates instances of ExceptionBeta and ExceptionGammer and
	 * throws them, and then catches them using catch blocks of type ExceptionBeta
	 * and ExceptionGammer respectively.
	 * 
	 * @param args the command line arguments as an array of String objects
	 */
	public static void main(String[] args) {
		CatHandler cat = new CatHandler();
		try {
			// Throwing an ExceptionBeta
			throw cat.new ExceptionBeta();
		} catch (ExceptionAlpha exception) {
			System.err.println("Caught an ExceptionBeta");
		}
		try {
			// Throwing an ExceptionGammer
			throw cat.new ExceptionGammer();
		} catch (ExceptionAlpha exception) {
			System.err.println("Caught an ExceptionGammer");
		}
	}

	/**
	 * 
	 * A custom exception class that extends from the base Exception class.
	 */
	class ExceptionAlpha extends Exception {
	}

	/**
	 * 
	 * A custom exception class that extends from ExceptionAlpha.
	 */
	class ExceptionBeta extends ExceptionAlpha {
	}

	/**
	 * 
	 * A custom exception class that extends from ExceptionBeta.
	 */
	class ExceptionGammer extends ExceptionBeta {
	}
}