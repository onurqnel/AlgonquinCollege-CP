
import java.io.IOException;

/**
 * 
 * This class demonstrates how to use try-catch blocks to handle various types
 * of exceptions in Java. It defines two custom exception classes, ExceptionDog
 * and ExceptionPuppy, as well as handling NullPointerException and IOException.
 */
public class DogHandler {

	/**
	 * The main method throws and catches various types of exceptions using
	 * try-catch blocks.
	 * 
	 * @param args the command line arguments as an array of String objects
	 */
	@SuppressWarnings("null")
	public static void main(String[] args) {
		DogHandler dog = new DogHandler();
		// Handling ExceptionDog
		try {
			throw dog.new ExceptionDog();
		} catch (ExceptionDog exception) {
			System.err.println("Caught an ExceptionDog");
		}

		// Handling ExceptionPuppy
		try {
			throw dog.new ExceptionPuppy();
		} catch (ExceptionPuppy exception) {
			System.err.println("Caught an ExceptionPuppy");
		}

		// Handling NullPointerException
		try {
			String nullString = null;
			nullString.length(); // This will cause a NullPointerException
		} catch (NullPointerException exception) {
			System.err.println("Caught a NullPointerException");
		}

		// Handling IOException
		try {
			throw new IOException("IOException Occured");
		} catch (IOException exception) {
			System.err.println("Caught an IOException: " + exception.getMessage());
		}
	}

	/**
	 * A custom exception class that extends from the base Exception class.
	 */
	class ExceptionDog extends Exception {

	}

	/**
	 * A custom exception class that extends from ExceptionDog.
	 */
	class ExceptionPuppy extends ExceptionDog {

	}

}
