
/**
 * This class demonstrates the importance of the arrangement of catch blocks
 * in exception handling, specifically showing a compilation error when
 * the superclass exception type is caught before the subclass exception type.
 */
import java.io.IOException;

public class OrderHandler {

	/**
	 * The main method demonstrates the importance of the order of catch blocks by
	 * trying to catch superclass and subclass exceptions in an incorrect order.
	 *
	 * @param args Command-line arguments (not used in this example)
	 */
	public static void main(String[] args) {

		try {
			throw new Exception();
			throw new IOException(); // This line will not be executed because the exception above is thrown
		} catch (Exception exception) {
			System.err.println("Caught exception in main: " + exception.getMessage());

			// The following catch block will cause a compilation error since it's placed
			// after catching the superclass exception
		} catch (IOException ioException) {
			System.err.println("Caught IOException in main: " + ioException.getMessage());
		}
	}
}
