/******************************************************
 * File:  ProfessorDao.java 
 * Course materials (23W) CST8277
 * 
 * @author Teddy Yap
 * @author Shariar (Shawn) Emami
 * @author (original) Mike Norman
 ******************************************************/

package databank.dao;

import java.util.List;
import databank.model.ProfessorPojo;

/**
 * Description: DAO interface for the Professor CRUD operations
 */
public interface ProfessorDao {

    /**
     * Create (persist) a new professor
     * @param professor the professor to create
     * @return the created professor with its assigned ID
     */
    ProfessorPojo createProfessor(ProfessorPojo professor);

    /**
     * Read (find) a professor by its ID
     * @param professorId the ID of the professor to find
     * @return the found professor or null if not found
     */
    ProfessorPojo readProfessorById(int professorId);

    /**
     * Read (find) all professors
     * @return a list of all professors
     */
    List<ProfessorPojo> readAllProfessors();

    /**
     * Update (modify) a professor
     * @param professor the professor with updated information
     */
    void updateProfessor(ProfessorPojo professor);

    /**
     * Delete a professor by its ID
     * @param professorId the ID of the professor to delete
     */
    void deleteProfessorById(int professorId);
}
