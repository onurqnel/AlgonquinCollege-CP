/************************************************************
 * File:  ProfessorController.java Course materials (23W) CST8277
 *
 * @author Teddy Yap
 * @author Shariar (Shawn) Emami
 * @author (original) Mike Norman
 */
package databank.jsf;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.SessionScoped;
import javax.faces.annotation.SessionMap;
import javax.inject.Inject;
import javax.inject.Named;

import databank.dao.ListDataDao;
import databank.dao.ProfessorDao;
import databank.model.ProfessorPojo;

@Named
@SessionScoped
public class ProfessorController implements Serializable {
	private static final long serialVersionUID = 1L;

	@Inject
	@SessionMap
	private Map<String, Object> sessionMap;

	@Inject
	private ProfessorDao professorDao;

	@Inject
	private ListDataDao listDataDao;

	private List<ProfessorPojo> professors;

	/**
	 * Loads professors into the current session.
	 */
	public void loadProfessors() {
		setProfessors(professorDao.readAllProfessors());
	}

	public List<ProfessorPojo> getProfessors() {
		return professors;
	}

	public void setProfessors(List<ProfessorPojo> professors) {
		this.professors = professors;
	}

	public List<String> getDegrees() {
		return this.listDataDao.readAllDegrees();
	}

	public List<String> getMajors() {
		return this.listDataDao.readAllMajors();
	}

	/**
	 * Navigates to add professor form.
	 * 
	 * @return the navigation path
	 */
	public String navigateToAddForm() {
		// Pay attention to the name here, it will be used as the object name in
		// add-professor.xhtml
		// ex. <h:inputText value="#{newProfessor.firstName}" id="firstName" />
		sessionMap.put("newProfessor", new ProfessorPojo());
		return "add-professor.xhtml?faces-redirect=true";
	}

	/**
	 * Submits a new professor for creation.
	 * 
	 * @param professor the professor to be created
	 * @return the navigation path
	 */
	public String submitProfessor(ProfessorPojo professor) {
		professor.setCreated(LocalDateTime.now());
		professorDao.createProfessor(professor);
		return "list-professors.xhtml?faces-redirect=true";
	}

	/**
	 * Navigates to update professor form.
	 * 
	 * @param professorId the ID of the professor to update
	 * @return the navigation path
	 */
	public String navigateToUpdateForm(int professorId) {
		ProfessorPojo foundProfessor = professorDao.readProfessorById(professorId);
		sessionMap.put("editedProfessor", foundProfessor);
		return "edit-professor.xhtml?faces-redirect=true";
	}

	/**
	 * Submits an updated professor for modification.
	 * 
	 * @param professor the professor with modified data
	 * @return the navigation path
	 */
	public String submitUpdatedProfessor(ProfessorPojo professor) {
		professorDao.updateProfessor(professor);
		return "list-professors.xhtml?faces-redirect=true";
	}

	/**
	 * Deletes a professor.
	 * 
	 * @param professorId the ID of the professor to delete
	 * @return the navigation path
	 */
	public String deleteProfessor(int professorId) {
		professorDao.deleteProfessorById(professorId);
		return "list-professors.xhtml?faces-redirect=true";
	}

}
