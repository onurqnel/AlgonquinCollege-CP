
/* 
 * Student Name: Onur Onel
 * Lab Professor: Professor George Kriger
 * Due Date: 01.17.2023
 * Project Name: Lab01
 * Description: 
 *
 */

import java.util.Scanner;

/**
 * @author Onur Onel
 * @version 1.0
 * @since javac 17.0.4.1
 */
/**
 * Driver is a public class which has a main method.
 * In main method, used setters and printed inputs from the user.
 */
public class Driver {
/**
 * Main method of this program.
 * 
 * @param args Main method arguments.
 */
	public static void main(String[] args) {

 
		Username userName = new Username(); //Username Instantiated new Username object called userName.
		Scanner scanner = new Scanner(System.in); //Created new Scanner object called scanner.

		System.out.print("Please enter your first name: ");
		String name = scanner.nextLine(); //Initialized the scanner class by using the appropriate constructor.
		userName.setFirstName(name); //Setted FirstName to the name using the new userName object.

		System.out.print("Please enter your last name: "); 
		String surName = scanner.nextLine(); 
		userName.setLastName(surName);

		System.out.print("Please enter your student number: "); 
		Long studentNo = scanner.nextLong();
		userName.setStudentNumber(studentNo);

		System.out.println("First name: " + name); 
		System.out.println("Last name: " + surName);
		System.out.println("Student number: " + studentNo);

		scanner.close(); //Closed the Scanner and allowed Java to reclaim the Scanner's memory.
	}
}
