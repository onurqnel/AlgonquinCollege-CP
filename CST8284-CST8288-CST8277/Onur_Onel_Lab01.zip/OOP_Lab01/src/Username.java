/* 
 * File name: OOP_Lab01 
 * Author: Onur Onel, 041074824
 * Course: CST8132 – OOP
 * Assignment: Lab 01
 * Date: 17.01.2023
 * Professor: George Kriger
 * Purpose: This program gets user information inputs from the user (first name, last name and student number).
 * Class list: Username.java, Driver.java
 */

/**
 * @author Onur Onel
 * @version 1.0
 * @since javac 17.0.4.1
 */
public class Username {

	private String firstName;
	private String lastName;
	private long studentNumber;
/**
 * Username is a public class constructor.
 */
	public Username() {

	}
/**
 * Username constructor using fields of this program.
 * @param firstName parameter specifies the first name of the user. 
 * @param lastName parameter specifies the surname of the user. 
 * @param studentNumber parameter specifies the student number of user. 
 */
	public Username(String firstName, String lastName, long studentNumber) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.studentNumber = studentNumber;
	}
/**
 * This method gets first name of the user.
 * @return Returns String object called firstName.
 */
	public String getFirstName() {
		return firstName;
	}
/**
 * This method sets the FirstName given name from the user.
 * @param firstName is String object of this set method.
 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
/**
 * This method gets surname of the user.
 * @return Returns String object called lastName.
 */
	public String getLastName() {
		return lastName;
	}
/**
 * This method sets the LastName given surname from the user.
 * @param lastName is String object of this set method.
 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
/**
 * This methods gets student number of the user.
 * @return Returns long object called studentNumber.
 */
	public long getStudentNumber() {
		return studentNumber;
	}
/**
 * This method sets the StudentNumber given number from the user.
 * @param studentNumber is String object of this set method. 
 */
	public void setStudentNumber(long studentNumber) {
		this.studentNumber = studentNumber;
	}

}
