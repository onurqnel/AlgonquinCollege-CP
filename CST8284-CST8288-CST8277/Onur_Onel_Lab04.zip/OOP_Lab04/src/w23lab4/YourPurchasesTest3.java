package w23lab4;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * The YourPurchasesTest3 class is used to test the YourPurchases class using
 * JUnit4.
 */
public class YourPurchasesTest3 {
	/**
	 * This constant represents the acceptable margin of error when comparing double
	 * values in the YourPurchasesTest3 class.
	 */
	private static final double EPSILON = 1E-12;

	/**
	 * Tests the getPayment() method when no payment has been made.
	 */
	@Test
	public void testGetPayment() {
		YourPurchases aPurchase = new YourPurchases();

		double expectedPayment = 0.0;
		assertEquals(expectedPayment, aPurchase.getPayment(), EPSILON);
	}

	/**
	 * Tests the getPayment() method after a payment of $5 has been made.
	 */
	@Test
	public void testGetPayment2() {
		YourPurchases aPurchase = new YourPurchases();

		aPurchase.receivePayment(5, 0, 0, 0, 0);
		assertEquals(5.0, aPurchase.getPayment(), EPSILON);
	}

	/**
	 * Tests the getPayment() method after a payment of $31.31 has been made using
	 * various coins.
	 */
	@Test
	public void testGetPayment3() {
		YourPurchases aPurchase = new YourPurchases();

		double expectedPayment = 31.31;
		aPurchase.receivePayment(31, 1, 0, 1, 1);
		assertEquals(expectedPayment, aPurchase.getPayment(), EPSILON);
	}
}
