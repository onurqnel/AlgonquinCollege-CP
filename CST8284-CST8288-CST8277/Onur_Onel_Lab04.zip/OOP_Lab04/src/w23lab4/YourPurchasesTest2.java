/**
 * Student Name: Onur Onel
 * 
 * Lab Professor: Professor George Kriger
 * 
 * Due Date: Feb 24, 2023 11:59 PM
 * 
 * Project Name: Lab04
 **/
package w23lab4;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * A class containing JUnit tests for the YourPurchases class.
 */
public class YourPurchasesTest2 {
	/**
	 * The maximum difference allowed between expected and actual values in the
	 * test.
	 */
	private static final double EPSILON = 1E-12;

	/**
	 * Tests the CalculateChange method of YourPurchases. It records a purchase of
	 * 1.5 and a payment of 5.0, and checks if CalculateChange method returns 3.50.
	 */
	@Test
	public void testCalculateChange() {
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.recordPurchase(1.5);
		aPurchase.receivePayment(5, 0, 0, 0, 0);
		double changeResult = aPurchase.CalculateChange();
		double expected = 3.50;
		Assert.assertEquals(expected, changeResult, EPSILON);
	}

	/**
	 * Tests the recordPurchase method of YourPurchases. It records a purchase of
	 * 9.99, and checks if getPurchase method returns 9.99.
	 */
	@Test
	public void testRecordPurchase() {
		YourPurchases aPurchase = new YourPurchases();

		double expectedAmount = 9.99;
		aPurchase.recordPurchase(expectedAmount);
		assertEquals(expectedAmount, aPurchase.getPurchase(), EPSILON);
	}

	/**
	 * Tests the giveChange method of YourPurchases. It records a purchase of 24.45
	 * and a payment of 25 dollars, and checks if giveChange method returns 0.55.
	 */
	@Test
	public void testGiveChange() {
		YourPurchases aPurchase = new YourPurchases();

		double purchase = 24.45;
		double change = 0.55;
		aPurchase.recordPurchase(purchase);
		aPurchase.receivePayment(20, 16, 7, 4, 10);
		assertEquals(change, aPurchase.giveChange(), EPSILON);
	}

	/**
	 * Tests the receivePayment method of YourPurchases. It receives a payment of 1
	 * dollar, 2 quarters, 3 dimes, 4 nickels, and 5 pennies, and checks if
	 * getPayment method returns 2.05.
	 */
	@Test
	public void testReceivePayment() {
		YourPurchases aPurchase = new YourPurchases();

		aPurchase.receivePayment(1, 2, 3, 4, 5);
		assertEquals(2.05, aPurchase.getPayment(), EPSILON);
	}

	/**
	 * Tests the YourPurchases class constructor by creating a new instance of the
	 * class and verifying that the initial payment and purchase amounts are set to
	 * 0.0.
	 */
	@Test
	public void testPurchaseConstructor() {
		YourPurchases aPurchase = new YourPurchases();
		double expectedPayment = 0.0;
		double expectedPurchase = 0.0;

		assertEquals(expectedPayment, aPurchase.getPayment(), EPSILON);
		assertEquals(expectedPurchase, aPurchase.getPurchase(), EPSILON);

	}
}
