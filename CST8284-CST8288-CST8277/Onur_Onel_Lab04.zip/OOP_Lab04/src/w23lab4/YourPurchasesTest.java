/**
 * Student Name: Onur Onel
 * 
 * Lab Professor: Professor George Kriger
 * 
 * Due Date: Feb 24, 2023 11:59 PM
 * 
 * Project Name: Lab04
 **/
package w23lab4;

import org.junit.Test;

import org.junit.Assert;

/**
 * A class containing JUnit tests for the YourPurchases class.
 */
public class YourPurchasesTest {
	/**
	 * The maximum difference allowed between expected and actual values in the
	 * test.
	 */
	private static final double EPSILON = 1E-12;

	/**
	 * Tests the getPurchase method of YourPurchases. It records a purchase of 2.0,
	 * and checks if getPurchase method returns 2.0.
	 */
	@Test
	public void testGetPayment() {
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.recordPurchase(2.0);
		double result = aPurchase.getPurchase();
		double expected = 2.0;
		Assert.assertEquals(expected, result, EPSILON);
	}
}