package acmecollege.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2023-11-20T16:32:06.457-0500")
@StaticMetamodel(AcademicStudentClub.class)
public class AcademicStudentClub_ extends StudentClub_ {
}
