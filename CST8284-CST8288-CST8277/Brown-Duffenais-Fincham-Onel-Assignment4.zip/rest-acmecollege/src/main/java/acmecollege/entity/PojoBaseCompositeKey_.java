package acmecollege.entity;

import java.time.LocalDateTime;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2023-11-23T16:16:29.387-0500")
@StaticMetamodel(PojoBaseCompositeKey.class)
public class PojoBaseCompositeKey_ {
	public static volatile SingularAttribute<PojoBaseCompositeKey, Integer> version;
	public static volatile SingularAttribute<PojoBaseCompositeKey, LocalDateTime> created;
	public static volatile SingularAttribute<PojoBaseCompositeKey, LocalDateTime> updated;
}
