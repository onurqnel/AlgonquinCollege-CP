package acmecollege.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2023-11-20T16:38:23.858-0500")
@StaticMetamodel(NonAcademicStudentClub.class)
public class NonAcademicStudentClub_ extends StudentClub_ {
}
