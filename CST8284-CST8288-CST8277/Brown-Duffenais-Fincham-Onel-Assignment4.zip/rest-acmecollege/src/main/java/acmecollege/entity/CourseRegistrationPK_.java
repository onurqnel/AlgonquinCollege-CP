package acmecollege.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2023-11-20T16:29:47.327-0500")
@StaticMetamodel(CourseRegistrationPK.class)
public class CourseRegistrationPK_ {
	public static volatile SingularAttribute<CourseRegistrationPK, Integer> studentId;
	public static volatile SingularAttribute<CourseRegistrationPK, Integer> courseId;
}
