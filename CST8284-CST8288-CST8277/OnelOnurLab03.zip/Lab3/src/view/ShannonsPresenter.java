/**
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section: 22S_CST8288_013
 * Declaration:
 * This code represents the original work of the author and is free from plagiarism.
 */
package view;

import model.ShannonsTheorem;

/*
 * The ShannonsPresenter class connects the ShannonsTheorem model and the ShannonsView GUI together.
 * It handles user interactions and data calculations for Shannon's Theorem application.
 * Shannon's Theorem calculates the maximum data rate of a communication channel given bandwidth,
 * signal power, and noise power.
 */
public class ShannonsPresenter {

    private final ShannonsTheorem model;
    private final ShannonsView view;

    /**
     * Constructs a ShannonsPresenter object with the given ShannonsTheorem
     * model and ShannonsView GUI. The constructor also attaches the necessary
     * event handlers for GUI components.
     *
     * @param model The ShannonsTheorem model used for data calculations.
     * @param view The ShannonsView GUI used for user interactions and data
     * display.
     */
    public ShannonsPresenter(ShannonsTheorem model, ShannonsView view) {
        this.model = model;
        this.view = view;
        attachViewEvents();
    }

    /**
     * Attaches event handlers to the GUI components. The event handler is
     * attached to the "Calculate" button, which triggers data calculations.
     */
    private void attachViewEvents() {
        view.calcBtn.setOnAction(e -> calculateData());
    }

    /**
     * Calculates the maximum data rate using Shannon's Theorem based on the
     * user input. The method extracts the bandwidth, signal power, and noise
     * power values from the GUI fields. It then sets these values in the
     * ShannonsTheorem model and calculates the maximum data rate. The result is
     * displayed in the GUI label. If the user enters invalid numbers, an error
     * message is displayed in the label.
     */
    private void calculateData() {
        try {
            double bandwidth = Double.parseDouble(view.bandFld.getText());
            double signalPower = Double.parseDouble(view.signalFld.getText());
            double noisePower = Double.parseDouble(view.noiseFld.getText());

            model.setBandWidth(bandwidth);
            model.setSignalPower(signalPower);
            model.setNoisePower(noisePower);

            double maxDataRate = model.maxDataRate();
            view.resultLbl.setText("Maximum Data Rate: " + maxDataRate + " bits per second");
        } catch (NumberFormatException e) {
            view.resultLbl.setText("Error: Please enter valid numbers.");
        }
    }
}
