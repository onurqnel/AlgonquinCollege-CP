/**
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section: 22S_CST8288_013
 * Declaration:
 * This code represents the original work of the author and is free from plagiarism.
 */
package view;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

/*
 * The ShannonsView class represents the graphical user interface (GUI) for Shannon's Theorem application.
 * It provides a form where the user can enter bandwidth, signal power, and noise power values.
 * The GUI includes labels, text fields, and a button to calculate the maximum data rate using Shannon's Theorem.
 *
 */
public class ShannonsView extends GridPane {

    // Labels
    Label bandwidth;
    Label averagePower;
    Label averageNoise;
    Label resultLbl;

    // Fields
    TextField bandFld = new TextField();
    TextField signalFld = new TextField();
    TextField noiseFld = new TextField();

    // Buttons
    Button calcBtn = new Button("Calculate");

    /**
     * Constructs a ShannonsView object. It initializes the labels, text fields,
     * and the calculate button. The form layout is set up by calling the
     * layoutForm() method.
     */
    public ShannonsView() {
        this.bandwidth = new Label("Enter Bandwidth");
        this.averagePower = new Label("Enter Average Power:");
        this.averageNoise = new Label("Enter Average Noise:");
        this.resultLbl = new Label("Result:");
        layoutForm();
    }

    /**
     * Sets up the layout of the GUI form. Labels, text fields, the calculate
     * button, and the result label are added to the grid. Vertical and
     * horizontal gaps are set to provide spacing between elements.
     */
    private void layoutForm() {
        // Adding labels to the grid
        this.add(bandwidth, 0, 0);
        this.add(averagePower, 0, 1);
        this.add(averageNoise, 0, 2);

        // Adding text fields to the grid
        this.add(bandFld, 1, 0);
        this.add(signalFld, 1, 1);
        this.add(noiseFld, 1, 2);

        // Adding the calculate button to the grid
        this.add(calcBtn, 1, 3);

        // Adding result label to the grid
        this.add(resultLbl, 0, 4, 2, 1); // spans 2 columns

        // Some padding and gaps between the grid elements
        this.setVgap(10); // Vertical gap
        this.setHgap(10); // Horizontal gap
    }
}
