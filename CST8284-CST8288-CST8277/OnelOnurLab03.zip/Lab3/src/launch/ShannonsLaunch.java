/**
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section: 22S_CST8288_013
 * Declaration:
 * This code represents the original work of the author and is free from plagiarism.
 */
package launch;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.ShannonsTheorem;
import view.ShannonsPresenter;
import view.ShannonsView;

/**
 * The ShannonsLaunch class is the entry point for the application. It launches
 * the JavaFX application and displays Shannon's Theorem GUI. Shannon's Theorem
 * calculates the maximum data rate of a communication channel. The application
 * uses the ShannonsTheorem model to perform calculations and the ShannonsView
 * to display the GUI.
 *
 * @author ONUR
 */
public class ShannonsLaunch extends Application {

    /**
     * The main method of the application. It calls the launch method from the
     * Application class to start the JavaFX application.
     *
     * @param args Command-line arguments (not used in this application).
     */
    public static void main(String[] args) {
        Application.launch(args);
    }

    /**
     * The start method is called when the JavaFX application is started. It
     * initializes the ShannonsTheorem model, ShannonsView, and
     * ShannonsPresenter. The ShannonsPresenter connects the model and view
     * together. The GUI scene is set up with the ShannonsView and displayed in
     * a Stage (window).
     *
     * @param primaryStage The primary Stage (window) of the JavaFX application.
     */
    @Override
    public void start(Stage primaryStage) {
        ShannonsTheorem model = new ShannonsTheorem();
        ShannonsView view = new ShannonsView();
        new ShannonsPresenter(model, view);

        Scene scene = new Scene(view, 400, 200);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Shannon's Theorem");
        primaryStage.show();
    }
}
