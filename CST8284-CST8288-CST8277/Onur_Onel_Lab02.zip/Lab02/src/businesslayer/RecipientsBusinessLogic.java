/*
Student Name: Onur Onel
Student Number: 041074824
Course & Section #: 22S_CST8288_013
Declaration:
This is my own original work and is free from Plagiarism.
 */
package businesslayer;

import dataaccesslayer.RecipientsDao;
import dataaccesslayer.RecipientsDaoImpl;
import java.util.List;
import transferobjects.RecipientsDTO;

/**
 * The RecipientsBusinessLogic class handles business logic operations related
 * to recipients.
 */
public class RecipientsBusinessLogic {

    private static final int NAME_MAX_LENGTH = 40;
    private static final int CITY_MAX_LENGTH = 30;
    private static final int CATEGORY_MAX_LENGTH = 40;

    private final RecipientsDao recipientsDao;

    /**
     * Class constructor. Initializes a new RecipientsDaoImpl object.
     */
    public RecipientsBusinessLogic() {
        recipientsDao = new RecipientsDaoImpl();
    }

    /**
     * Retrieves all recipients.
     *
     * @return a list of all recipients
     */
    public List<RecipientsDTO> getAllRecipients() {
        return recipientsDao.getAllRecipients();
    }

    /**
     * Inserts a recipient, validates the recipient, and prints the recipient.
     *
     * @param recipient the recipient to be inserted and printed
     * @throws ValidationException if the recipient is invalid
     */
public void insertAndPrintRecipient(RecipientsDTO recipient) throws ValidationException {
    validateRecipient(recipient);
    recipientsDao.insertAndPrintRecipient(recipient);
}


    /**
     * Deletes a recipient and prints the recipient.
     *
     * @param recipient the recipient to be deleted and printed
     * @throws ValidationException if the recipient is invalid
     */
    public void deleteAndPrintRecipient(RecipientsDTO recipient) throws ValidationException {
        validateRecipient(recipient);
        recipientsDao.deleteAndPrintRecipient(recipient);
        getAllRecipients();
    }


    /**
     * Validates the recipient.
     *
     * @param recipient the recipient to be validated
     * @throws ValidationException if the recipient is invalid
     */
    private void validateRecipient(RecipientsDTO recipient) throws ValidationException {
        validateString(recipient.getName(), "Name", NAME_MAX_LENGTH, true);
        validateString(recipient.getCity(), "City", CITY_MAX_LENGTH, true);
        validateString(recipient.getCategory(), "Category", CATEGORY_MAX_LENGTH, true);

    }

    /**
     * Validates the provided string based on the provided parameters.
     *
     * @param value the string to be validated
     * @param fieldName the name of the field
     * @param maxLength the maximum allowed length of the string
     * @param isNullAllowed whether null is allowed for the string
     * @throws ValidationException if the string is invalid
     */
    private void validateString(String value, String fieldName, int maxLength, boolean isNullAllowed)
            throws ValidationException {
        if (value == null) {
            if (!isNullAllowed) {
                throw new ValidationException(String.format("%s cannot be null", fieldName));
            } // null permitted, nothing to validate
        } else if (value.length() == 0) {
            throw new ValidationException(String.format("%s cannot be empty or only whitespace", fieldName));
        } else if (value.length() > maxLength) {
            throw new ValidationException(String.format("%s cannot exceed %d characters", fieldName, maxLength));
        }
    }
}
