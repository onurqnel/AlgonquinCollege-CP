/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */

package businesslayer;

/**
 * Custom exception class for validation errors.
 */
public class ValidationException extends Exception {

    /**
     * Constructs a new ValidationException with a default error message.
     */
    public ValidationException() {
        super("Data not in valid format");
    }

    /**
     * Constructs a new ValidationException with the specified error message.
     *
     * @param message the error message
     */
    public ValidationException(String message) {
        super(message);
    }

    /**
     * Constructs a new ValidationException with the specified error message and cause.
     *
     * @param message the error message
     * @param cause   the cause of the exception
     */
    public ValidationException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructs a new ValidationException with the specified cause.
     *
     * @param cause the cause of the exception
     */
    public ValidationException(Throwable cause) {
        super(cause);
    }
}
