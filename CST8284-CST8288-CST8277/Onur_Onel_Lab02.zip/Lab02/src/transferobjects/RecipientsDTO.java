/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package transferobjects;

/**
 * The RecipientsDTO class represents a recipient object with its attributes.
 */
public class RecipientsDTO {

    private int AwardID;
    private int Year;
    private String Name;
    private String City;
    private String Category;

    /**
     * Returns the award ID of the recipient.
     *
     * @return the award ID
     */
    public int getAwardID() {
        return AwardID;
    }

    /**
     * Returns the name of the recipient.
     *
     * @return the name
     */
    public String getName() {
        return Name;
    }

    /**
     * Returns the year of the recipient.
     *
     * @return the year
     */
    public int getYear() {
        return Year;
    }

    /**
     * Returns the city of the recipient.
     *
     * @return the city
     */
    public String getCity() {
        return City;
    }

    /**
     * Returns the category of the recipient.
     *
     * @return the category
     */
    public String getCategory() {
        return Category;
    }

    /**
     * Sets the award ID of the recipient.
     *
     * @param AwardID the award ID to set
     */
    public void setAwardID(int AwardID) {
        this.AwardID = AwardID;
    }

    /**
     * Sets the name of the recipient.
     *
     * @param Name the name to set
     */
    public void setName(String Name) {
        this.Name = Name;
    }

    /**
     * Sets the year of the recipient.
     *
     * @param Year the year to set
     */
    public void setYear(int Year) {
        this.Year = Year;
    }

    /**
     * Sets the city of the recipient.
     *
     * @param City the city to set
     */
    public void setCity(String City) {
        this.City = City;
    }

    /**
     * Sets the category of the recipient.
     *
     * @param Category the category to set
     */
    public void setCategory(String Category) {
        this.Category = Category;
    }

    @Override
    public String toString() {
        return "RecipientsDTO{" + "AwardID=" + AwardID + ", Year=" + Year + ", Name=" + Name + ", City=" + City + ", Category=" + Category + '}';
    }
}
