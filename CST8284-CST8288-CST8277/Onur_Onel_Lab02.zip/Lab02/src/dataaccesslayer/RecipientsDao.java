/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */

package dataaccesslayer;

import java.util.List;
import transferobjects.RecipientsDTO;

/**
 * The interface for accessing and manipulating recipient data in the database.
 */
public interface RecipientsDao {
    
    /**
     * Retrieves all recipients from the database.
     *
     * @return a list of RecipientsDTO objects representing all recipients
     */
    List<RecipientsDTO> getAllRecipients();
    
    /**
     * Inserts a new recipient into the database and prints the inserted recipient.
     *
     * @param recipient the recipient to insert
     */
    void insertAndPrintRecipient(RecipientsDTO recipient);
    
    /**
     * Deletes a recipient from the database and prints the deleted recipient.
     *
     * @param recipient the recipient to delete
     */
    void deleteAndPrintRecipient(RecipientsDTO recipient);
}
