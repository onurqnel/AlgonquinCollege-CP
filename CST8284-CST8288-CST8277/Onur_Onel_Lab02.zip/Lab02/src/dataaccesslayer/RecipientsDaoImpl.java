/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */

package dataaccesslayer;

import com.mysql.cj.jdbc.result.ResultSetMetaData;
import java.util.List;
import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import transferobjects.RecipientsDTO;

/**
 * The RecipientsDaoImpl class provides implementation for the RecipientsDao interface.
 * It interacts with the database to perform CRUD operations on the Recipients table.
 */
public class RecipientsDaoImpl implements RecipientsDao {

    /**
     * Retrieves all recipients from the database.
     *
     * @return a list of RecipientsDTO objects representing the recipients.
     */
@Override
public List<RecipientsDTO> getAllRecipients() {
    List<RecipientsDTO> recipients = new ArrayList<>();
    String query = "SELECT AwardID, Name, City, Year, Category FROM Recipients ORDER BY AwardID";

    DataSource ds = new DataSource();
    try (
        Connection con = ds.createConnection();
        PreparedStatement pstmt = con.prepareStatement(query);
        ResultSet rs = pstmt.executeQuery();
    ) {

        ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();

        int numCols = rsmd.getColumnCount();

        System.out.println("Table Contents:");

        for(int i=1; i<=numCols; i++){
            System.out.printf("%-30s", rsmd.getColumnName(i) + " (" + rsmd.getColumnTypeName(i) + ", " + rsmd.getColumnClassName(i) + ")");
        }
        System.out.println();

        while (rs.next()) {
            RecipientsDTO recipient = new RecipientsDTO();
            recipient.setAwardID(rs.getInt("AwardID"));
            recipient.setName(rs.getString("Name"));
            recipient.setCity(rs.getString("City"));
            recipient.setYear(rs.getInt("Year"));
            recipient.setCategory(rs.getString("Category"));

            System.out.printf("%-30d", recipient.getAwardID());
            System.out.printf("%-30s", recipient.getName());
            System.out.printf("%-30s", recipient.getCity());
            System.out.printf("%-30d", recipient.getYear());
            System.out.printf("%-30s", recipient.getCategory());
            System.out.println();

            recipients.add(recipient);
        }
    } catch (SQLException e) {
        System.err.println("SQL Exception occurred while fetching the recipients data. " + e.getMessage());
    }
    return recipients;
}


    /**
     * Inserts a recipient into the database and prints the inserted recipient.
     *
     * @param recipient the RecipientsDTO object representing the recipient to be inserted.
     */
    @Override
    public void insertAndPrintRecipient(RecipientsDTO recipient) {
        String query = "INSERT INTO Recipients (Name, City, Year, Category) VALUES (?, ?, ?, ?)";

        DataSource ds = new DataSource();
        try (
            Connection con = ds.createConnection();
            PreparedStatement pstmt = con.prepareStatement(query);
        ) {
            pstmt.setString(1, recipient.getName());
            pstmt.setString(2, recipient.getCity());
            pstmt.setInt(3, recipient.getYear());
            pstmt.setString(4, recipient.getCategory());
            pstmt.executeUpdate();

            System.out.println("Inserted Recipient: " + recipient);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Deletes a recipient from the database and prints the deleted recipient.
     *
     * @param recipient the RecipientsDTO object representing the recipient to be deleted.
     */
    @Override
    public void deleteAndPrintRecipient(RecipientsDTO recipient) {
        String query = "DELETE FROM Recipients WHERE AwardID = ?";

        DataSource ds = new DataSource();
        try (
            Connection con = ds.createConnection();
            PreparedStatement pstmt = con.prepareStatement(query);
        ) {
            pstmt.setInt(1, recipient.getAwardID());
            pstmt.executeUpdate();

            System.out.println("Deleted Recipient: " + recipient);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
