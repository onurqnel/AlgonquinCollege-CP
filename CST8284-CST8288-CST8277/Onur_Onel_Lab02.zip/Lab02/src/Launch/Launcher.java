/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */

package Launch;

/**
 * The Launcher class is responsible for launching the SimpleDemo program.
 */
public class Launcher {

    /**
     * The main method that launches the SimpleDemo program.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        (new SimpleDemo()).demo();
    }
}
