/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */

package Launch;

import businesslayer.RecipientsBusinessLogic;
import businesslayer.ValidationException;
import transferobjects.RecipientsDTO;

import java.util.List;
import java.util.Scanner;

/**
 * The SimpleDemo class demonstrates the use of the RecipientsBusinessLogic class by providing an interactive menu for manipulating recipients.
 */
public class SimpleDemo {
    private final RecipientsBusinessLogic logic;

    /**
     * Constructs a SimpleDemo object and initializes the RecipientsBusinessLogic instance.
     */
    public SimpleDemo() {
        logic = new RecipientsBusinessLogic();
    }

    /**
     * Runs the demonstration of recipient operations.
     */
    public void demo() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Print all recipients");
            System.out.println("2. Insert a new recipient");
            System.out.println("3. Delete the last recipient");
            System.out.println("4. Quit");
            System.out.print("Enter a choice: ");

            int choice = scanner.nextInt();

            try {
                switch (choice) {
                    case 1:
                        printAllRecipients();
                        break;
                    case 2:
                        insertRecipient();
                        break;
                    case 3:
                        deleteLastRecipient();
                        break;
                    case 4:
                        System.out.println("Goodbye!");
                        return;
                    default:
                        System.out.println("Invalid choice. Please enter a number between 1 and 4.");
                        break;
                }
            } catch (ValidationException e) {
                System.err.println(e.getMessage());
            }
        }
    }

    /**
     * Prints all recipients.
     *
     * @throws ValidationException if a validation error occurs
     */
    private void printAllRecipients() throws ValidationException {
        List<RecipientsDTO> list = logic.getAllRecipients();
    }

    /**
     * Inserts a new recipient.
     *
     * @throws ValidationException if a validation error occurs
     */
    private void insertRecipient() throws ValidationException {
        RecipientsDTO recipient = new RecipientsDTO();
        recipient.setName("RecipientTestAdd");
        recipient.setCity("CityTestAdd");
        recipient.setCategory("CategoryTestAdd");
        logic.insertAndPrintRecipient(recipient);
    }

    /**
     * Deletes the last recipient.
     *
     * @throws ValidationException if a validation error occurs
     */
    private void deleteLastRecipient() throws ValidationException {
        List<RecipientsDTO> list = logic.getAllRecipients();
        RecipientsDTO recipient = list.get(list.size() - 1);
        logic.deleteAndPrintRecipient(recipient);
    }

    /**
     * The main method that launches the SimpleDemo program.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new SimpleDemo().demo();
    }
}
