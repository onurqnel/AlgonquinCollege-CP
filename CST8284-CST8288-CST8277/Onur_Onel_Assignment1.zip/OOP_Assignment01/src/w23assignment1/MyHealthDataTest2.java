package w23assignment1;

/**
 * 
 * Student Name: Onur Onel
 * 
 * Lab Professor: Professor George Kriger
 * 
 * Due Date: Feb 26, 2023 11:59 PM
 * 
 * Project Name: Assignment 1: Patient.java
 * 
 **/
import static org.junit.Assert.*;
import org.junit.Test;

/**
 * 
 * @author Onur Onel
 * @version 1.0
 */
public class MyHealthDataTest2 {
	/**
	 * This code creates a constant variable named EPSILON of type double with a
	 * value of 10E-3.
	 */
	private static final double EPSILON = 10E-3;

	/**
	 * This method tests the getHeight method of the Patient class.
	 */
	@Test
	public void testGetHeight() {
		// Create a new patient instance
		Patient patient = new Patient();

		// Call the getHeight method on the patient and store the result
		double height = patient.getHeight();

		// Verify that the height returned is within a small margin of error from 0
		assertEquals("Test successfully passed", 0.0, height, EPSILON);
	}

	/**
	 * This method tests the getWeight method of the Patient class.
	 */
	@Test
	public void testGetWeight() {
		// Create a new patient instance
		Patient patient = new Patient();

		// Call the getWeight method on the patient and store the result
		double weight = patient.getWeight();

		// Verify that the weight returned is within a small margin of error from 0
		assertEquals("Test successfully passed", 0.0, weight, EPSILON);
	}

	/**
	 * This method tests the squareOfHeight method of the Patient class.
	 */
	@Test
	public void testSquareOfHeight() {
		// Create a new patient instance
		Patient patient = new Patient();

		// Calculate the square of the patient's height and store the result
		double squareOfHeight = Math.pow(patient.getHeight(), 2.0);

		// Verify that the square of height returned is within a small margin of error
		// from 0
		assertEquals("Test successfully passed", 0.0, squareOfHeight, EPSILON);
	}

	/**
	 * This method tests the getBMI method of the Patient class.
	 */
	@Test
	public void testBMI() {
		// Create a new patient instance
		Patient patient = new Patient();

		// Set the patient's weight and height to specific values
		patient.setWeight(4);
		patient.setHeight(10);

		// Verify that the calculated BMI is within a small margin of error from the
		// expected value
		assertEquals("Test successfully passed", 28.12, patient.getBMI(), EPSILON);
	}
}