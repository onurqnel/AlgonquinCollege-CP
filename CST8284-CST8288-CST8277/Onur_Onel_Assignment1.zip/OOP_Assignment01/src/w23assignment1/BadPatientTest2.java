package w23assignment1;

/**
 * 
 * Student Name: Onur Onel
 * 
 * Lab Professor: Professor George Kriger
 * 
 * Due Date: Feb 26, 2023 11:59 PM
 * 
 * Project Name: Assignment 1: BadsPatient.java
 * 
 **/
import static org.junit.Assert.*;
import org.junit.Test;

/**
 * 
 * @author Onur Onel
 * @version 1.0
 */
public class BadPatientTest2 {
	/**
	 * This code creates a constant variable named EPSILON of type double with a
	 * value of 10E-3.
	 */
	private static final double EPSILON = 10E-3;

	/**
	 * Determines whether the calculated Body Mass Index (BMI) falls within an
	 * acceptable margin of error from the expected value.
	 */
	@Test
	public void testBMI() {
		// Create a new patient instance
		BadPatient badPatient = new BadPatient();

		// Set the patient's weight and height to specific values
		badPatient.setWeight(123);
		badPatient.setHeight(456);

		// Can not verify that the calculated BMI is within a small margin of error from
		// the expected value and fails.
		assertEquals("Test fails", 18.55, badPatient.getBMI(), EPSILON);
	}
}