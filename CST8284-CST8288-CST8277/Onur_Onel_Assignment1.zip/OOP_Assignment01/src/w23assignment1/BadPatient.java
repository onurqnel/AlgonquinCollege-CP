package w23assignment1;

import java.time.Year;

/**
 * 
 * Student Name: Onur Onel
 * 
 * Lab Professor: Professor George Kriger
 * 
 * Due Date: Feb 26, 2023 11:59 PM
 * 
 * Project Name: Assignment 1: BadPatient.java
 * 
 * Description: * The `BadPatient` class is used to represent information about a
 * patient. It has fields for the patient's first name, last name, gender, birth
 * year, birth month, birth day, height, and weight. It also provides methods
 * for calculating and displaying the patient's age,maximum heart rate, target
 * heart rate range, Body Mass Index (BMI), and BMI categories.
 **/
/**
 * 
 * @author Onur Onel
 * @version 1.0
 *
 */
public class BadPatient {

	/**
	 * The first name of the patient.
	 */
	private String firstname;

	/**
	 * The last name of the patient.
	 */
	private String lastname;

	/**
	 * The gender of the patient.
	 */
	private String gender;

	/**
	 * The birth year of the patient.
	 */
	private int birthYear;

	/**
	 * The birth month of the patient.
	 */
	private int birthMonth;

	/**
	 * The birth day of the patient.
	 */
	private int birthDay;

	/**
	 * The height of the patient in inches.
	 */
	private double height;

	/**
	 * The weight of the patient in pounds.
	 */
	private double weight;

	/**
	 * Constructs a new `BadPatient` object with the given information.
	 *
	 * @param firstname  the patient's first name
	 * @param lastname   the patient's last name
	 * @param gender     the patient's gender
	 * @param birthYear  the patient's birth year
	 * @param birthMonth the patient's birth month
	 * @param birthDay   the patient's birth day
	 * @param height     the patient's height in inches
	 * @param weight     the patient's weight in pounds
	 */
	public BadPatient(String firstname, String lastname, String gender, int birthYear, int birthMonth, int birthDay,
			double height, double weight) {
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.birthYear = birthYear;
		this.birthMonth = birthMonth;
		this.birthDay = birthDay;
		this.height = height;
		this.weight = weight;
	}

	/**
	 * Constructs a new `BadPatient` object with default values for all fields.
	 */
	public BadPatient() {
	}

	/**
	 * Returns the patient's first name.
	 *
	 * @return the patient's first name
	 */
	public String getFirstname() {
		return firstname;
	}

	/**
	 * Sets the patient's first name.
	 *
	 * @param firstname the patient's new first name
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	/**
	 * Returns the patient's last name.
	 *
	 * @return the patient's last name
	 */
	public String getLastname() {
		return lastname;
	}

	/**
	 * Sets the patient's last name.
	 *
	 * @param lastname the patient's new last name
	 */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	/**
	 * Returns the patient's gender.
	 *
	 * @return the patient's gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * Sets the patient's gender.
	 *
	 * @param gender the patient's new gender
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * Returns the patient's birth year.
	 *
	 * @return the patient's birth year
	 */
	public int getBirthYear() {
		return birthYear;
	}

	/**
	 * Sets the patient's birth year.
	 *
	 * @param birthYear the patient's new birth year
	 */
	public void setBirthYear(int birthYear) {
		this.birthYear = birthYear;
	}

	/**
	 * Returns the patient's birth month.
	 *
	 * @return the patient's birth month
	 */
	public int getBirthMonth() {
		return birthMonth;
	}

	/**
	 * Sets the patient's birth month.
	 *
	 * @param birthMonth the patient's new birth month
	 */
	public void setBirthMonth(int birthMonth) {
		this.birthMonth = birthMonth;
	}

	/**
	 * Returns the patient's birth day.
	 *
	 * @return the patient's birth day
	 */
	public int getBirthDay() {
		return birthDay;
	}

	/**
	 * Sets the patient's birth day.
	 *
	 * @param birthDay the patient's new birth day
	 */
	public void setBirthDay(int birthDay) {
		this.birthDay = birthDay;
	}

	/**
	 * Returns the patient's height in inches.
	 *
	 * @return the patient's height in inches
	 */
	public double getHeight() {
		return height;
	}

	/**
	 * Sets the patient's height in inches.
	 *
	 * @param height the patient's new height in inches
	 */
	public void setHeight(double height) {
		this.height = height;
	}

	/**
	 * Returns the patient's weight in pounds.
	 *
	 * @return the patient's weight in pounds
	 */
	public double getWeight() {
		return weight;
	}

	/**
	 * Sets the patient's weight in pounds.
	 *
	 * @param weight the patient's new weight in pounds
	 */
	public void setWeight(double weight) {
		this.weight = weight;
	}

	/**
	 * Returns the patient's age.
	 *
	 * @return the patient's age
	 */
	public int getAge() {
		return Year.now().getValue() - birthYear;
	}

	/**
	 * Returns the patient's maximum heart rate, calculated as 220 minus the
	 * patient's birth year.
	 *
	 * @return the patient's maximum heart rate
	 */
	public int getMaximumHeartRate() {
		return 220 - getAge();
	}

	/**
	 * Returns the patient's maximum target heart rate, calculated as 85% of the
	 * maximum heart rate.
	 *
	 * @return the patient's maximum target heart rate
	 */
	public int getMaximumTargetHeartRate() {
		return (int) (getMaximumHeartRate() * 0.85);
	}

	/**
	 * Returns the patient's minimum target heart rate, calculated as 50% of the
	 * maximum heart rate.
	 *
	 * @return the patient's minimum target heart rate
	 */
	public int getMinimumTargetHeartRate() {
		return (int) (getMaximumHeartRate() * 0.5);
	}

	/**
	 * ******************** This method intentionally produces an incorrect Body
	 * Mass Index (BMI) calculation for JUnit testing purposes. The purpose of this
	 * method is to simulate a scenario where the BMI calculation is incorrect or
	 * flawed, so that the JUnit test can verify that the BMI calculation code is
	 * working as expected.
	 *
	 * @return the incorrectly calculated BMI value ********************
	 */
	public double getBMI() { // height 10 //weight 4
		return (getWeight() / 703) / (getHeight() * getHeight());
	}

	/**
	 * Returns the patient's target heart rate, calculated as the average of the
	 * patient's maximum and minimum target heart rates.
	 *
	 * @return the patient's target heart rate
	 */
	public int getTargetHeartRate() {
		return (int) ((getMaximumHeartRate() + getMinimumTargetHeartRate()) / 2.0);

	}

	/**
	 * Displays the patient's age, maximum heart rate, target heart rate range, Body
	 * Mass Index (BMI), and BMI categories.
	 */
	public void displayMyHealthData() {

		System.out.printf("\n%-20s %s\n", "First Name:", getFirstname());
		System.out.printf("%-20s %s\n", "Last Name:", getLastname());
		System.out.printf("%-20s %s\n", "Gender:", getGender());
		System.out.printf("%-20s %s\n", "Height(inches):", getHeight());
		System.out.printf("Enter Weight(pounds) " + getWeight());
		System.out.printf("\n%-20s %s (yyyy-mm-dd)", "Birthday:",
				getBirthYear() + " " + getBirthMonth() + " " + getBirthDay());
		System.out.printf("\n%-20s %d", "Age:", getAge());
		System.out.printf("\n%-20s %.2f %s", "BMI:", getBMI(), "(kg/m^2)");
		System.out.printf("\n%-20s %d %s", "Maximum Heart Rate:", getMaximumHeartRate(), "(bpm)");
		System.out.printf("\n%-20s %d %s", "Target Heart Rate:", getTargetHeartRate(), "(bpm)");
		System.out.printf("\n", "");
		System.out.println("BMI VALUES");
		System.out.println("Underweight: less than 18.5");
		System.out.println("Normal:      between 18.5 and 24.9");
		System.out.println("Overweight:  between 25 and 29.9");
		System.out.println("Obese:       30 or greater");
	}

}
