package w23assignment1;

/**
 * 
 * Student Name: Onur Onel
 * 
 * Lab Professor: Professor George Kriger
 * 
 * Due Date: Feb 26, 2023 11:59 PM
 * 
 * Project Name: Assignment 1: Patient.java
 * 
 * Description: * The `Patient` class is used to represent information about a
 * patient. It has fields for the patient's first name, last name, gender, birth
 * year, birth month, birth day, height, and weight. It also provides methods
 * for calculating and displaying the patient's age,maximum heart rate, target
 * heart rate range, Body Mass Index (BMI), and BMI categories.
 **/
import java.util.Scanner;

/**
 * 
 * @author Onur Onel
 * @version 1.0
 *
 */
public class MyHealthDataTest {
	/**
	 * The main method takes input for patient's personal information and displays
	 * them
	 *
	 * @param args An array of strings containing the command line arguments.
	 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Patient patient = new Patient();

		System.out.println("Please enter first name: ");
		String name = scanner.nextLine();
		patient.setFirstname(name);

		System.out.println("Please enter last name: ");
		String surname = scanner.nextLine();
		patient.setLastname(surname);

		System.out.println("Please enter gender: ");
		String gender = scanner.nextLine();
		patient.setGender(gender);

		System.out.println("Please enter your height(inches): ");
		double height = scanner.nextDouble();
		patient.setHeight(height);

		System.out.println("Please enter your weight(pounds): ");
		double weight = scanner.nextDouble();
		patient.setWeight(weight);

		System.out.println("Please enter your birth year: ");
		int birthYear = scanner.nextInt();
		patient.setBirthYear(birthYear);

		System.out.println("Please enter the number of birth month: ");
		int birthOfMonth = scanner.nextInt();
		patient.setBirthMonth(birthOfMonth);

		System.out.println("Please enter day of birth: ");
		int birthDay = scanner.nextInt();
		patient.setBirthDay(birthDay);

		patient.displayMyHealthData();
		scanner.close();

	}
}
