/**
 * File:  PojoBase.java Course materials CST 8277
 * 
 * @author Mike Norman
 * 
 */
package com.algonquincollege.cst8277.lab.modelentities;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;

@SuppressWarnings("unused")

/**
 * Abstract class that is base of (class) hierarchy for all @Entity classes
 */
@JsonInclude(JsonInclude.Include.NON_NULL) // Only non-null fields in JSON
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "entity-type")
@JsonSubTypes({ @Type(value = EntityA.class, name = "typeA"), 
		@Type(value = EntityB.class, name = "typeB"),
		@Type(value = EntityCHasManyDees.class, name = "typeC"),
		@Type(value = EntityDHasManyCees.class, name = "typeD"), 
		@Type(value = EntityEHasMany.class, name = "typeE"),
		@Type(value = EntityFHasManyToOneBackReference.class, name = "typeF") })
public abstract class PojoBase implements Serializable {
	private static final long serialVersionUID = 1L;

	protected int id;
	protected int version;
	protected LocalDateTime created;
	protected String foobar;

	public PojoBase() {
		this.setCreated(LocalDateTime.now());
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public LocalDateTime getCreated() {
		return this.created;
	}

	public void setCreated(LocalDateTime created) {
		this.created = created;
	}

	@JsonProperty("msg")
	public String getFoobar() {
		return foobar;
	}

	public void setFoobar(String foobar) {
		this.foobar = foobar;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		return prime * result + Objects.hash(getId());
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (obj instanceof PojoBase otherPojoBase) {
			return Objects.equals(this.getId(), otherPojoBase.getId());
		}
		return false;
	}

}