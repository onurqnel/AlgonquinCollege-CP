/**
 * File:  AllTestCases.java
 * 
 */
package com.algonquincollege.cst8277.lab;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({TestEntitiesSystem.class /*, Other future TestSuite classes */})
public class AllTestCases {
}