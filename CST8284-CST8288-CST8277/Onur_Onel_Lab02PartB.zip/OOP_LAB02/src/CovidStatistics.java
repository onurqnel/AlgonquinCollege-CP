
/* 
 *  Student Name: Onur Onel
 *  
 *  Lab Professor: Professor George Kriger
 *  
 *  Due Date: 02.03.2023
 *  
 *  Project Name: Lab02 Part-B
 *  
 *  Description: Shows the number of people who have recovered from COVID-19 Across 7 provinces
 *  in Canada Over a period of 8 months (Feb. to Sept. 2020).
 *  Sums up the number of recovered persons across Canada 
 *  for each month. Prints a formatted output using printf...
 *
 */

/**
 * 
 * Public class CovidStatistics prints number of people who have recovered from
 * COVID-19 Across 7 provinces in Canada. Rows represents provinces, columns are
 * months. Then calculates and prints out the total number of recovered people
 * for each month.
 *
 * @author Onur Onel
 * @version 2.0
 */

public class CovidStatistics {
	/**
	 * The main method that runs the program and prints tables statistics.
	 *
	 * @param args command line arguments.
	 */
	public static void main(String[] args) {
		final int ROWS = 7; // number of provinces
		final int COLUMNS = 8; // number of months

		int[][] patients = { { 2200, 1100, 1200, 1000, 1015, 2000, 1092, 2204 },
				{ 5020, 6105, 2009, 9047, 1016, 2014, 2708, 2308 }, { 1720, 2406, 3054, 1018, 1023, 3100, 1406, 1502 },
				{ 1490, 2002, 2016, 5008, 2044, 1055, 1607, 2201 }, { 1520, 1007, 1092, 2065, 1023, 1010, 1046, 1502 },
				{ 1670, 1201, 2008, 2001, 1086, 1009, 1041, 1706 }, { 1870, 2001, 2078, 1006, 1053, 1702, 1009, 1406 }

		};

		String[] provinces = { "Ontario", "Quebec", "Nova Scotia", "New Brunswick", "Manitoba", "British Columbia",
				"Prince Edward Island" };

		System.out.printf("%20s%8s%10s%8s%7s%8s%8s%8s%8s%11s", "Month", "Feb", "March", "April", "May", "June", "July",
				"Aug", "Sept", "Maximum");
		System.out.println();

        // These nested for loops prints the statistics for each province.
		for (int i = 0; i < ROWS; i++) {
			System.out.printf("%n %20s", provinces[i]); // Printing provinces with the rows.

			int max = 0;
			for (int j = 0; j < COLUMNS; j++) {
				System.out.printf("    " + patients[i][j]);// Printing statistics with row number i, and column number j.
															
				if (patients[i][j] > max) {
					max = patients[i][j];
				}
			}
			System.out.printf("%8d", max);
		}

		System.out.println();
		System.out.println();
		System.out.printf("%22s", "Recovered Patients");
        // These nested for loops prints the summary of statistics for each month.
		for (int i = 0; i < COLUMNS; i++) {
			int summary = 0;
			for (int j = 0; j < ROWS; j++) {
				summary += patients[j][i]; // Sums up the numbers of the recovered persons across Canada for each month.
			}
			System.out.printf("%8d", summary);
		}
		System.out.println();
		System.out.println();
		System.out.printf("%60s", "Vaccinate and maintain good health practices!");
	}
}