/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package dataaccesslayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import transferobject.PeerTutor;

/**
 * This class provides data access methods related to peer tutors and courses.
 */
public class PeerTutorDAOImpl implements PeerTutorDAO {

    /**
     * Checks if a peer tutor is registered in the system.
     *
     * @param peerTutor The PeerTutor object to check for registration.
     * @return true if the peer tutor is registered, false otherwise.
     */
    @Override
    public boolean isPeerTutorRegistered(PeerTutor peerTutor) {
        DataSource ds = new DataSource();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        boolean isRegistered = false;

        try {
            // Establish the database connection
            conn = ds.createConnection();

            // SQL query to check if the peer tutor is registered
            String sql = "SELECT COUNT(*) FROM PeerTutor WHERE firstName = ? AND lastName = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, peerTutor.getFirstName());
            pstmt.setString(2, peerTutor.getLastName());
            rs = pstmt.executeQuery();
            if (rs.next()) {
                isRegistered = rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources in the finally block to ensure they are released properly
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return isRegistered;
    }

    /**
     * Checks if a course with the specified code exists in the system.
     *
     * @param courseCode The code of the course to check.
     * @return true if the course exists, false otherwise.
     */
    @Override
    public boolean isCourseValid(String courseCode) {
        DataSource ds = new DataSource();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        boolean isValid = false;

        try {
            // Establish the database connection
            conn = ds.createConnection();

            // SQL query to check if the course exists
            String sql = "SELECT COUNT(*) FROM Course WHERE CourseCode = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, courseCode);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                isValid = rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources in the finally block to ensure they are released properly
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return isValid;
    }

    /**
     * Checks if the given peer tutor has taken a course with the specified
     * code.
     *
     * @param peerTutor The PeerTutor object to check.
     * @param courseCode The code of the course to check.
     * @return true if the peer tutor has taken the course, false otherwise.
     */
    @Override
    public boolean hasPeerTutorTakenCourse(PeerTutor peerTutor, String courseCode) {
        DataSource ds = new DataSource();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        boolean hasTaken = false;

        try {
            // Establish the database connection
            conn = ds.createConnection();

            // SQL query to check if the peer tutor has taken the course
            String sql = "SELECT COUNT(*) FROM TutorCourses WHERE peerTutorID = ? AND courseCode = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, peerTutor.getPeerTutorID());
            pstmt.setString(2, courseCode);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                hasTaken = rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources in the finally block to ensure they are released properly
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return hasTaken;
    }

    /**
     * Retrieves the letter grade for a specific course of the given peer tutor.
     *
     * @param peerTutor The PeerTutor object for which to retrieve the letter
     * grade.
     * @param courseCode The code of the course to get the letter grade for.
     * @return The letter grade of the peer tutor for the given course, or null
     * if not found.
     */
    @Override
    public String getPeerTutorLetterGradeForCourse(PeerTutor peerTutor, String courseCode) {
        DataSource ds = new DataSource();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String grade = null;

        try {
            // Establish the database connection
            conn = ds.createConnection();

            // SQL query to retrieve the letter grade of the peer tutor for the given course
            String sql = "SELECT GradeCode FROM Grade "
                    + "WHERE Student_StudentID = (SELECT StudentID FROM Student WHERE LastName = ? AND FirstName = ?) "
                    + "AND Course_CourseCode = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, peerTutor.getLastName());
            pstmt.setString(2, peerTutor.getFirstName());
            pstmt.setString(3, courseCode);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                grade = rs.getString("GradeCode");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources in the finally block to ensure they are released properly
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return grade;
    }

    /**
     * Checks if a course is already assigned to the given peer tutor.
     *
     * @param peerTutor The PeerTutor object to check for course assignment.
     * @param courseCode The code of the course to check assignment for.
     * @return true if the course is already assigned to the peer tutor, false
     * otherwise.
     */
    @Override
    public boolean isCourseAlreadyAssignedToPeerTutor(PeerTutor peerTutor, String courseCode) {
        DataSource ds = new DataSource();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        boolean isAssigned = false;

        try {
            // Establish the database connection
            conn = ds.createConnection();

            // SQL query to check if the course is already assigned to the peer tutor
            String sql = "SELECT COUNT(*) AS count "
                    + "FROM peertutor.peertutorcourse "
                    + "JOIN peertutor.peertutor ON peertutorcourse.PeerTutor_PeerTutorID = peertutor.PeerTutorID "
                    + "WHERE Course_CourseCode = ? AND LastName = ? AND FirstName = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, courseCode);
            pstmt.setString(2, peerTutor.getLastName());
            pstmt.setString(3, peerTutor.getFirstName());
            rs = pstmt.executeQuery();
            if (rs.next()) {
                isAssigned = rs.getInt("count") > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources in the finally block to ensure they are released properly
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return isAssigned;
    }

    /**
     * Assigns a course to a peer tutor.
     *
     * @param peerTutor The PeerTutor object to assign the course to.
     * @param courseCode The code of the course to assign.
     */
    @Override
    public void assignCourseToPeerTutor(PeerTutor peerTutor, String courseCode) {
        DataSource ds = new DataSource();
        Connection conn = null;
        PreparedStatement pstmtSelect = null;
        PreparedStatement pstmtInsert = null;
        ResultSet rs = null;

        try {
            // Establish the database connection
            conn = ds.createConnection();

            // SQL query to retrieve the PeerTutorID using the LastName and FirstName
            String sqlSelect = "SELECT PeerTutorID FROM PeerTutor WHERE LastName = ? AND FirstName = ?";
            pstmtSelect = conn.prepareStatement(sqlSelect);
            pstmtSelect.setString(1, peerTutor.getLastName());
            pstmtSelect.setString(2, peerTutor.getFirstName());

            // Execute the select query
            rs = pstmtSelect.executeQuery();

            if (rs.next()) {
                int peerTutorID = rs.getInt("PeerTutorID");

                // SQL query to insert the course assignment into PeerTutorCourse table
                String sqlInsert = "INSERT INTO PeerTutorCourse(PeerTutor_PeerTutorID, Course_CourseCode) VALUES (?, ?)";
                pstmtInsert = conn.prepareStatement(sqlInsert);
                pstmtInsert.setInt(1, peerTutorID);
                pstmtInsert.setString(2, courseCode);

                // Execute the insert query
                pstmtInsert.executeUpdate();
            } else {
                System.err.println("Error: No PeerTutor found with the given LastName and FirstName.");
            }
        } catch (SQLException e) {
            System.err.println("SQLException: " + e.getMessage());
            System.err.println("SQLState: " + e.getSQLState());
            System.err.println("VendorError: " + e.getErrorCode());
        } finally {
            // Close resources in the finally block to ensure they are released properly
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmtSelect != null) {
                    pstmtSelect.close();
                }
                if (pstmtInsert != null) {
                    pstmtInsert.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                System.err.println("SQLException on close: " + e.getMessage());
                System.err.println("SQLState on close: " + e.getSQLState());
                System.err.println("VendorError on close: " + e.getErrorCode());
            }
        }
    }

    /**
     * Retrieves a list of all peer tutors for a specific course.
     *
     * @param courseCode The code of the course to get peer tutors for.
     * @return A list of PeerTutor objects representing peer tutors for the
     * course.
     */
    @Override
    public List<PeerTutor> getAllPeerTutorsForCourse(String courseCode) {
        DataSource ds = new DataSource();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<PeerTutor> peerTutors = new ArrayList<>();

        try {
            // Establish the database connection
            conn = ds.createConnection();

            // SQL query to get peer tutors for the specified course code
            String sql = "SELECT PeerTutor.PeerTutorID, PeerTutor.FirstName, PeerTutor.LastName FROM PeerTutor "
                    + "JOIN PeerTutorCourse ON PeerTutor.PeerTutorID = PeerTutorCourse.PeerTutor_PeerTutorID "
                    + "WHERE PeerTutorCourse.Course_CourseCode = ?";

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, courseCode);
            rs = pstmt.executeQuery();

            // Process the result set and populate the list of peer tutors
            while (rs.next()) {
                PeerTutor tutor = new PeerTutor();
                tutor.setPeerTutorID(rs.getInt("PeerTutorID"));
                tutor.setFirstName(rs.getString("FirstName"));
                tutor.setLastName(rs.getString("LastName"));
                peerTutors.add(tutor);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources in the finally block to ensure they are released properly
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return peerTutors;
    }
}
