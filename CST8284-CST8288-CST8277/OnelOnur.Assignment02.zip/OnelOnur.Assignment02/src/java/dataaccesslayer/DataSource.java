/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package dataaccesslayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * This class provides a DataSource to establish a database connection.
 */
public class DataSource {

    /**
     * Default constructor for DataSource.
     */
    public DataSource() {
    }

    /**
     * Creates a connection to the database using the provided credentials.
     *
     * @return A Connection object representing the established database connection.
     * @throws SQLException if a database access error occurs.
     */
    public Connection createConnection() throws SQLException {
        Connection connection = null;
        try {
            // Database connection details
            String url = "jdbc:mysql://localhost:3306/peertutor?useSSL=false";
            String username = "root";
            String password = "123";

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connection established to " + url);
        } catch (SQLException e) {
            // Handle any database connection errors
            e.printStackTrace();
            throw e;
        }
        return connection;
    }
}
