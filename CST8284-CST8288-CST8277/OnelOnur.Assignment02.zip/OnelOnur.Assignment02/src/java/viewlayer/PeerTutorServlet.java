/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package viewlayer;

import businesslayer.PeerTutorBusinessLogic;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import transferobject.PeerTutor;

/**
 * The PeerTutorServlet class is a servlet that processes requests related to
 * peer tutors and their courses.
 */
public class PeerTutorServlet extends HttpServlet {

    /**
     * Processes GET and POST requests related to peer tutors and their courses.
     *
     * @param request The HttpServletRequest object representing the client's
     * request.
     * @param response The HttpServletResponse object representing the response
     * to be sent to the client.
     * @throws ServletException If an error occurs while processing the request.
     * @throws IOException If an I/O error occurs while processing the request.
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            // Create a PeerTutorBusinessLogic instance to handle business logic
            PeerTutorBusinessLogic logic = new PeerTutorBusinessLogic();

            // Retrieve parameters from the request
            String lastName = request.getParameter("lastName");
            String firstName = request.getParameter("firstName");
            String courseCode = request.getParameter("courseCode");

            // Create a PeerTutor object with the retrieved parameters
            PeerTutor tutor = new PeerTutor();
            tutor.setLastName(lastName);
            tutor.setFirstName(firstName);

            // Start generating the HTML response
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet PeerTutorServlet</title>");
            out.println("</head>");
            out.println("<body BGCOLOR=\"#FDF5E6\">");
            out.println("<h1>Servlert PeerTutorServlet at " + request.getContextPath() + "</h1>");

            // Check if the peer tutor is registered
            if (!logic.isPeerTutorRegistered(tutor)) {
                out.println("<ul>");
                out.println("<li>Last Name: " + lastName);
                out.println("<li>First Name: " + firstName);
                out.println("</ul>");
                out.println("<h3> Error: The person is not registered as a peer tutor. </h3>");
            } // Check if the course code is valid
            else if (!logic.isCourseValid(courseCode)) {
                out.println("<ul>");
                out.println("<li>Course Code: " + courseCode);
                out.println("</ul>");
                out.println("<h3> Error: Invalid course. </h3>");
            } else {
                // Get the letter grade of the peer tutor for the given course
                String grade = logic.getPeerTutorLetterGradeForCourse(tutor, courseCode);
                if (grade == null) {
                    out.println("<ul>");
                    out.println("<li>Last Name: " + lastName);
                    out.println("<li>First Name: " + firstName);
                    out.println("<li>Course Code: " + courseCode);
                    out.println("</ul>");
                    out.println("<h3> Error: The peer tutor has not taken the course. </h3>");
                } else {
                    // Check if the peer tutor's grade is sufficient to be a tutor for the course
                    boolean isTutor = false;
                    String[] passGrades = {"A+", "A", "A-"};
                    for (String s : passGrades) {
                        if (grade.equals(s)) {
                            isTutor = true;
                            break;
                        }
                    }
                    if (!isTutor) {
                        out.println("<ul>");
                        out.println("<li>Last Name: " + lastName);
                        out.println("<li>First Name: " + firstName);
                        out.println("<li>Course Code: " + courseCode);
                        out.println("<li>Grade: " + grade);
                        out.println("</ul>");
                        out.println("<h3> Error: The letter grade obtained by the peer tutor for the course is not sufficient. </h3>");
                    } // Check if the peer tutor is already assigned to the course
                    else if (!logic.isCourseAlreadyAssignedToPeerTutor(tutor, courseCode)) {
                        // Assign the course to the peer tutor
                        logic.assignCourseToPeerTutor(tutor, courseCode);
                        out.println("<h3>Course assigned successfully</h3>");
                        out.println("<p>Table of Peer Tutors for " + courseCode + "</p>");
                        out.println("<table border=\"1\">");
                        out.println("<tr><th>Tutor ID</th><th>Last Name</th><th>First Name</th></tr>");
                        // Get all peer tutors assigned to the course and display them in a table
                        List<PeerTutor> assignedTutors = logic.getAllPeerTutorsForCourse(courseCode);
                        for (PeerTutor tutorItem : assignedTutors) {
                            out.println("<tr>");
                            out.println("<td>" + tutorItem.getPeerTutorID() + "</td>");
                            out.println("<td>" + tutorItem.getLastName() + "</td>");
                            out.println("<td>" + tutorItem.getFirstName() + "</td>");
                            out.println("</tr>");
                        }
                        out.println("</table>");
                    } else if (logic.isCourseAlreadyAssignedToPeerTutor(tutor, courseCode)) {
                        out.println("<ul>");
                        out.println("<li>Last Name: " + lastName);
                        out.println("<li>First Name: " + firstName);
                        out.println("<li>Course Code: " + courseCode);
                        out.println("</ul>");
                        out.println("<h3> Error: The peer tutor is already assigned to the course. </h3>");
                    }
                }
            }
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
