/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package transferobject;

/**
 * The PeerTutor class represents a peer tutor with their unique ID, last name, and first name.
 */
public class PeerTutor {

    private int peerTutorID;
    private String lastName;
    private String firstName;

    /**
     * Get the ID of the peer tutor.
     *
     * @return The peer tutor ID.
     */
    public int getPeerTutorID() {
        return peerTutorID;
    }

    /**
     * Get the last name of the peer tutor.
     *
     * @return The last name of the peer tutor.
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Get the first name of the peer tutor.
     *
     * @return The first name of the peer tutor.
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Set the ID of the peer tutor.
     *
     * @param peerTutorID The peer tutor ID to set.
     */
    public void setPeerTutorID(int peerTutorID) {
        this.peerTutorID = peerTutorID;
    }

    /**
     * Set the last name of the peer tutor.
     *
     * @param lastName The last name of the peer tutor to set.
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Set the first name of the peer tutor.
     *
     * @param firstName The first name of the peer tutor to set.
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
}
