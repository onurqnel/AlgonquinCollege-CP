/*
 * Student Name: Onur Onel
 * Student Number: 041074824
 * Course & Section #: 22S_CST8288_013
 * Declaration:
 * This is my own original work and is free from Plagiarism.
 */
package businesslayer;

import dataaccesslayer.PeerTutorDAO;
import dataaccesslayer.PeerTutorDAOImpl;
import java.util.List;
import transferobject.PeerTutor;

/**
 * This class represents the business logic for managing peer tutors.
 */
public class PeerTutorBusinessLogic {

    private final PeerTutorDAO peerTutorDAO;

    /**
     * Constructs a new PeerTutorBusinessLogic object with a default PeerTutorDAO implementation.
     */
    public PeerTutorBusinessLogic() {
        this.peerTutorDAO = new PeerTutorDAOImpl();
    }

    /**
     * Checks if a peer tutor is registered in the system.
     *
     * @param peerTutor The PeerTutor object to check.
     * @return true if the peer tutor is registered, false otherwise.
     */
    public boolean isPeerTutorRegistered(PeerTutor peerTutor) {
        return peerTutorDAO.isPeerTutorRegistered(peerTutor);
    }

    /**
     * Checks if a course code is valid and exists in the system.
     *
     * @param courseCode The code of the course to check.
     * @return true if the course is valid, false otherwise.
     */
    public boolean isCourseValid(String courseCode) {
        return peerTutorDAO.isCourseValid(courseCode);
    }

    /**
     * Checks if a peer tutor has taken a specific course.
     *
     * @param peerTutor  The PeerTutor object to check.
     * @param courseCode The code of the course to check.
     * @return true if the peer tutor has taken the course, false otherwise.
     */
    public boolean hasPeerTutorTakenCourse(PeerTutor peerTutor, String courseCode) {
        return peerTutorDAO.hasPeerTutorTakenCourse(peerTutor, courseCode);
    }

    /**
     * Gets the letter grade of a peer tutor for a specific course.
     *
     * @param peerTutor  The PeerTutor object to check.
     * @param courseCode The code of the course to check.
     * @return The letter grade of the peer tutor for the given course.
     */
    public String getPeerTutorLetterGradeForCourse(PeerTutor peerTutor, String courseCode) {
        return peerTutorDAO.getPeerTutorLetterGradeForCourse(peerTutor, courseCode);
    }

    /**
     * Checks if a course is already assigned to a peer tutor.
     *
     * @param peerTutor  The PeerTutor object to check.
     * @param courseCode The code of the course to check.
     * @return true if the course is already assigned, false otherwise.
     */
    public boolean isCourseAlreadyAssignedToPeerTutor(PeerTutor peerTutor, String courseCode) {
        return peerTutorDAO.isCourseAlreadyAssignedToPeerTutor(peerTutor, courseCode);
    }

    /**
     * Assigns a course to a peer tutor.
     *
     * @param peerTutor  The PeerTutor object to assign the course to.
     * @param courseCode The code of the course to assign.
     */
    public void assignCourseToPeerTutor(PeerTutor peerTutor, String courseCode) {
        peerTutorDAO.assignCourseToPeerTutor(peerTutor, courseCode);
    }

    /**
     * Retrieves a list of all peer tutors for a specific course.
     *
     * @param courseCode The code of the course to get peer tutors for.
     * @return A list of PeerTutor objects representing peer tutors for the course.
     */
    public List<PeerTutor> getAllPeerTutorsForCourse(String courseCode) {
        return peerTutorDAO.getAllPeerTutorsForCourse(courseCode);
    }
}
