package w23lab5;

/**
 * The main method creates SalesAgent objects of different types and prints out
 * their string representations.
 */
public class SalesAgentTest {
	/**
	 * @param args the command line arguments.
	 */
	public static void main(String[] args) {

		SalesAgent firstAgent = new SalesAgent("Jhon", 28);
		SalesAgent secondAgent = new SalesAgent("Mike", 31);
		SalesSupervisor agentSuperVisor = new SalesSupervisor("Hakan", 26, "Izmir");
		SalesChief agentChief = new SalesChief("Onur", 20, "Antalya", "Marketing");

		System.out.println(firstAgent.toString());
		System.out.println(secondAgent.toString());
		System.out.println(agentSuperVisor.toString());
		System.out.println(agentChief.toString());
	}
}