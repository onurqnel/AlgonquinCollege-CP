package w23lab5;

/**
 * The SalesChief class represents a sales chief, which is a type of sales
 * supervisor with an additional department attribute.
 */
public class SalesChief extends SalesSupervisor {
	/**
	 * The department of the sales chief.
	 */
	private String department;

	/**
	 * Constructs a SalesChief object with the specified name, age, location, and
	 * department.
	 *
	 * @param name       the name of the sales chief
	 * @param age        the age of the sales chief
	 * @param location   the location of the sales chief
	 * @param department the department of the sales chief
	 */
	public SalesChief(String name, int age, String location, String department) {
		super(name, age, location);
		this.department = department;
	}

	/**
	 * Returns the department of the sales chief.
	 *
	 * @return the department of the sales chief
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * Sets the department of the sales chief.
	 *
	 * @param department the new department of the sales chief
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * Returns a string representation of the SalesChief object.
	 *
	 * @return a string representation of the SalesChief object
	 */
	@Override
	public String toString() {
		return "Sales Chief [super = " + super.toString() + ", Department = " + department + "]";
	}

}
