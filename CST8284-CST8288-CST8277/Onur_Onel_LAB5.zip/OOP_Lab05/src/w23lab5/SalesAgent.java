package w23lab5;

// This is CST 8284 Lab 5. Follow all instructions stated in your Lab slides carefully.
// Include all the items required in this class.

/**
 * The SalesAgent class represents a sales agent with a name and age.
 */
public class SalesAgent {
	/**
	 * The name of the Sales Agent.
	 */
	private String name;
	/**
	 * The age of the Sales Agent.
	 */
	private int age;

	/**
	 * Constructs a SalesAgent object with the specified name and age.
	 *
	 * @param name the name of the Sales Agent
	 * @param age  the age of the Sales Agent
	 */
	public SalesAgent(String name, int age) {
		this.name = name;
		this.age = age;
	}

	/**
	 * Returns the name of the SalesAgent.
	 *
	 * @return the name of the SalesAgent
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name of the SalesAgent.
	 *
	 * @param name the new name of the SalesAgent
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Returns the age of the SalesAgent.
	 *
	 * @return the age of the SalesAgent
	 */
	public int getAge() {
		return age;
	}

	/**
	 * Sets the age of the SalesAgent.
	 *
	 * @param age the new age of the SalesAgent
	 */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * Returns a string representation of the SalesAgent object.
	 *
	 * @return a string representation of the SalesAgent object
	 */
	public String toString() {
		return "Sales Agent [name = " + name + ", age = " + age + "]";
	}
}
