package w23lab5;

/**
 * The SalesSupervisor class represents a sales supervisor, which is a type of
 * sales agent with an additional location attribute.
 */
public class SalesSupervisor extends SalesAgent {
	/**
	 * The location of the sales supervisor.
	 */
	private String location;

	/**
	 * Constructs a SalesSupervisor object with the specified name, age, and
	 * location.
	 *
	 * @param name     the name of the sales supervisor
	 * @param age      the age of the sales supervisor
	 * @param location the location of the sales supervisor
	 */
	public SalesSupervisor(String name, int age, String location) {
		super(name, age);
		this.location = location;
	}

	/**
	 * Returns the location of the sales supervisor.
	 *
	 * @return the location of the sales supervisor
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * Sets the location of the sales supervisor.
	 *
	 * @param location the new location of the sales supervisor
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * Returns a string representation of the SalesSupervisor object.
	 *
	 * @return a string representation of the SalesSupervisor object
	 */
	@Override
	public String toString() {
		return "Sales Supervisor [super = " + super.toString() + ", Location = " + location + "]";
	}
}
