package w23lab5;

import java.util.Random;

/**
 * The SalesAgentTest2 class is a program that tests the SalesAgent class and
 * its subclasses.
 */
public class SalesAgentTest2 {
	/**
	 * The maximum number of SalesAgent objects in the array.
	 */
	public static final int MAX_AGENT = 31;

	/**
	 * The main method creates an array of SalesAgent objects and prints out their
	 * string representations.
	 * 
	 * @param args the command line arguments.
	 */
	public static void main(String[] args) {
// Part A
		SalesAgent firstAgent = new SalesAgent("Jhon", 28);
		SalesAgent secondAgent = new SalesAgent("Mike", 31);
		SalesSupervisor agentSuperVisor = new SalesSupervisor("Hakan", 26, "Izmir");
		SalesChief agentChief = new SalesChief("Onur", 20, "Antalya", "Marketing");

		SalesAgent[] agentsArray = { firstAgent, secondAgent, agentSuperVisor, agentChief };

		// Print out the string representation of each SalesAgent object in the array
		int i = 0;
		while (i < agentsArray.length) {
			System.out.println(agentsArray[i].toString());
			i++;
		}
		// Part B
		SalesAgent[] newAgents = new SalesAgent[MAX_AGENT];
		for (int j = 0; j < MAX_AGENT; j++) {
			SalesAgent randomAgent = new SalesAgent(randomName(), randomAge());
			newAgents[j] = randomAgent;
			System.out.println(newAgents[j]);
		}
	}

	/**
	 * This class generates random SalesAgent objects with random names and ages.
	 * 
	 * @return A random name between NAMES array.
	 */
	public static String randomName() {
		String[] NAMES = { "Alice", "Bob", "Charlie", "David", "Emily", "Frank", "Grace", "Henry", "Isabel", "Jack" };
		return NAMES[(int) (Math.random() * NAMES.length)];
	}

	/**
	 * 
	 * Generates a random age for a SalesAgent.
	 * 
	 * @return A random age between 18 and 68.
	 */
	public static int randomAge() {
		Random rand = new Random();
		int age = rand.nextInt(50) + 18;
		return age;
	}
}
