/*
Student Name: Onur Onel
Student Number: 041074824
Course & Section #: 22S_CST8288_013
Declaration:
This is my own original work and is free from Plagiarism.
 */
package pkgUnitConverterTest;

import pkgUnitConverter.*;

/**
 * Test class to demonstrate the usage of the Strategy pattern in converting
 * different units. The units under test in this case are Temperature
 * (Fahrenheit to Celsius and vice versa) and Distance (Kilometers to Miles and
 * vice versa).
 *
 * This class uses the UnitConverter class, which employs the Strategy pattern,
 * to convert between these units.
 *
 * @author Onur Onel
 */
public class UnitConverterTest {

    /**
     * The main method creates instances of UnitConverter with different
     * strategies and uses them to convert between different units.
     *
     * The output is then printed to the console.
     *
     * @param args command line arguments (not used)
     */
    public static void main(String[] args) {
        // Create a UnitConverter for temperature conversions, initially set to convert from Celsius to Fahrenheit
        UnitConverter temperatureConverter = new UnitConverter(new CFconverter());
        System.out.printf("%5.2f in Celsius is %5.2f Fahrenheit\n", 20.0, temperatureConverter.convert(20.0));

        // Change the strategy of the UnitConverter to convert from Fahrenheit to Celsius
        temperatureConverter.setConversionStrategy(new FCconverter());
        System.out.printf("%5.2f in Fahrenheit is %5.2f Celsius\n", 70.0, temperatureConverter.convert(70.0));

        // Create a UnitConverter for distance conversions, initially set to convert from Kilometers to Miles
        UnitConverter distanceConverter = new UnitConverter(new KmToMilesConverter());
        System.out.printf("%5.2f Kilometers is %5.2f Miles\n", 10.0, distanceConverter.convert(10.0));

        // Change the strategy of the UnitConverter to convert from Miles to Kilometers
        distanceConverter.setConversionStrategy(new MilesToKmConverter());
        System.out.printf("%5.2f Miles is %5.2f Kilometers\n", 6.21371, distanceConverter.convert(6.21371));
    }
}
