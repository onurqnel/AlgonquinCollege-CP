/*
Student Name: Onur Onel
Student Number: 041074824
Course & Section #: 22S_CST8288_013
Declaration:
This is my own original work and is free from Plagiarism.
 */
package pkgUnitConverter;

/**
 * Class representing a general UnitConverter which uses Strategy Pattern. This
 * allows the converter to flexibly adapt its conversion algorithm at runtime.
 *
 * @author Onur Onel
 */
public class UnitConverter {

    /**
     * The conversion strategy to use in this converter.
     */
    private Strategy conversionStrategy;

    /**
     * Constructor for the UnitConverter class.
     *
     * @param convStrategy The initial conversion strategy to use in this
     * converter.
     */
    public UnitConverter(Strategy convStrategy) {
        this.conversionStrategy = convStrategy;
    }

    /**
     * Changes the conversion strategy of this converter to the provided
     * strategy.
     *
     * @param convStrategy The new conversion strategy to use.
     */
    public void setConversionStrategy(Strategy convStrategy) {
        this.conversionStrategy = convStrategy;
    }

    /**
     * Converts the provided unit value using the current conversion strategy.
     *
     * @param unit The unit value to convert.
     * @return The converted unit value.
     */
    public double convert(double unit) {
        return conversionStrategy.convert(unit);
    }
}
