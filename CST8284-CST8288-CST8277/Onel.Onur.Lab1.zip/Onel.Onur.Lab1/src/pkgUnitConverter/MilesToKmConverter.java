/*
Student Name: Onur Onel
Student Number: 041074824
Course & Section #: 22S_CST8288_013
Declaration:
This is my own original work and is free from Plagiarism.
 */
package pkgUnitConverter;

/**
 * Class that implements the Strategy interface to provide a conversion
 * mechanism from Miles to Kilometers. This class is part of the strategy
 * pattern implemented to convert different units.
 *
 * The conversion from Miles to Kilometers is done using the factor: 1 mile =
 * 1.60934 kilometers
 *
 * @author Onur Onel
 */
public class MilesToKmConverter implements Strategy {

    private final double convFactor = 1.60934;

    /**
     * Converts a given value from Miles to Kilometers using the factor: 1 mile
     * = 1.60934 kilometers
     *
     * @param miles The value in Miles to be converted to Kilometers.
     * @return The converted value in Kilometers.
     */
    @Override
    public double convert(double miles) {
        return miles * convFactor;
    }
}
