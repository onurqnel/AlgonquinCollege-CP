/*
Student Name: Onur Onel
Student Number: 041: Onur Onel
Stude074824
Course & Section #: 22S_CST8288_013
Declaration:
This is my own original work and is free from Plagiarism.
 */
package pkgUnitConverter;

/**
 * Class that implements the Strategy interface to provide a conversion
 * mechanism from Kilometers to Miles. This class is part of the strategy
 * pattern implemented to convert different units.
 *
 * The conversion from Kilometers to Miles is done using the factor: 1 km =
 * 0.621371 mile
 *
 * @author Onur Onel
 */
public class KmToMilesConverter implements Strategy {

    private final double convFactor = 0.621371;

    /**
     * Converts a given value from Kilometers to Miles using the factor: 1 km =
     * 0.621371 mile
     *
     * @param km The value in Kilometers to be converted to Miles.
     * @return The converted value in Miles.
     */
    @Override
    public double convert(double km) {
        return km * convFactor;
    }
}
