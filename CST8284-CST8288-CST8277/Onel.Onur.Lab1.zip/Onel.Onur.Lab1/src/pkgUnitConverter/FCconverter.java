/*
Student Name: Onur Onel
Student Number: 041074824
Course & Section #: 22S_CST8288_013
Declaration:
This is my own original work and is free from Plagiarism.
 */
package pkgUnitConverter;

/**
 * Class that implements the Strategy interface to provide a conversion
 * mechanism from Fahrenheit to Celsius. This class is part of the strategy
 * pattern implemented to convert different units.
 *
 * The conversion from Fahrenheit to Celsius is done using the formula: C = (F -
 * 32) / 1.8
 *
 * @author Onur Onel
 */
public class FCconverter implements Strategy {

    private final double convFactor = 1.8;
    private final double convOrigin = 32.0;

    /**
     * Converts a given value from Fahrenheit to Celsius using the formula: C =
     * (F - 32) / 1.8
     *
     * @param fahrenheit The value in Fahrenheit to be converted to Celsius.
     * @return The converted value in Celsius.
     */
    @Override
    public double convert(double fahrenheit) {
        return (fahrenheit - convOrigin) / convFactor;
    }
}
