/*
Student Name: Onur Onel
Student Number: 041074824
Course & Section #: 22S_CST8288_013
Declaration:
This is my own original work and is free from Plagiarism.
 */
package pkgUnitConverter;

/**
 * This is an interface that provides a contract for all concrete conversion
 * strategy classes. Every strategy must implement the convert() method.
 *
 * @author Onur Onel
 */
public interface Strategy {

    /**
     * This method is responsible for the actual conversion process. It will be
     * implemented by each concrete strategy class.
     *
     * @param unit the unit value that needs to be converted
     * @return the converted unit value
     */
    public double convert(double unit);
}
