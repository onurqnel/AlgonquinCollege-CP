/*
Student Name: Onur Onel
Student Number: 041074824
Course & Section #: 22S_CST8288_013
Declaration:
This is my own original work and is free from Plagiarism.
 */
package pkgUnitConverter;

/**
 * Class that implements the Strategy interface to provide a conversion
 * mechanism from Celsius to Fahrenheit. This class is part of the strategy
 * pattern implemented to convert different units.
 *
 * The conversion from Celsius to Fahrenheit is done using the formula: F = C *
 * 1.8 + 32
 *
 * @author Onur Onel
 */
public class CFconverter implements Strategy {

    private final double convFactor = 1.8;
    private final double convOrigin = 32.0;

    /**
     * Converts a given value from Celsius to Fahrenheit using the formula: F =
     * C * 1.8 + 32
     *
     * @param celsius The value in Celsius to be converted to Fahrenheit.
     * @return The converted value in Fahrenheit.
     */
    @Override
    public double convert(double celsius) {
        return celsius * convFactor + convOrigin;
    }
}
