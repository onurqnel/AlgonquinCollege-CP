const form = document.querySelector("form");
const emailInput = document.getElementById("email");
const loginInput = document.getElementById("login");
const passInput = document.getElementById("pass");
const pass2Input = document.getElementById("pass2");
const termsInput = document.getElementById("terms");
const emailError = document.getElementById("email-error");
const loginError = document.getElementById("login-error");
const passError = document.getElementById("pass-error");
const pass2Error = document.getElementById("pass2-error");
const termsError = document.getElementById("terms-error");

function validateEmail(email) {
  const mailPattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  return email.match(mailPattern);
}

function validateLogin(login) {
  return login.length > 0 && login.length < 20;
}

function validatePassword(password) {
  const pwdPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{6,}$/;
  return password.length >= 6 && password.match(pwdPattern);
}

function validatePasswordMatch(pass, pass2) {
  return pass === pass2 && pass !== "" && pass2 !== "";
}

function validateTerms(terms) {
  return terms.checked;
}

function submit(event) {
  event.preventDefault();

  emailError.textContent = "";
  loginError.textContent = "";
  passError.textContent = "";
  pass2Error.textContent = "";
  termsError.textContent = "";

  const email = emailInput.value.trim();
  const login = loginInput.value.trim();
  const password = passInput.value.trim();
  const password2 = pass2Input.value.trim();
  const terms = termsInput;

  emailInput.classList.remove("is-invalid");
  loginInput.classList.remove("is-invalid");
  passInput.classList.remove("is-invalid");
  pass2Input.classList.remove("is-invalid");

  if (!validateEmail(email)) {
    emailError.textContent =
      " Email address should be non-empty with the format xyx@xyz.xyz.";
    emailError.classList.add("error-message");
    emailInput.classList.add("is-invalid");
  }

  if (!validateLogin(login)) {
    loginError.textContent =
      " User name should be non-empty, and within 20 characters long.";
    loginError.classList.add("error-message");
    loginInput.classList.add("is-invalid");
  } else {
    loginInput.value = login.toLowerCase();
  }

  if (!validatePassword(password)) {
    passError.textContent =
      " Password must be at least 6 characters: 1 uppercase, 1 lowercase.";
    passError.classList.add("error-message");
    passInput.classList.add("is-invalid");
  }

  if (!validatePasswordMatch(password, password2)) {
    pass2Error.textContent = " Please retype password.";
    pass2Error.classList.add("error-message");
    pass2Input.classList.add("is-invalid");
  }

  if (!validateTerms(terms)) {
    termsError.textContent = " Please accept the terms and conditions";
    termsError.classList.add("error-message");
  }

  if (
    validateEmail(email) &&
    validateLogin(login) &&
    validatePassword(password) &&
    validatePasswordMatch(password, password2) &&
    validateTerms(terms)
  ) {
    alert("Data is valid!!");
    form.reset();
  }
}

function termsAlert(event) {
  if (event.target.checked) {
    alert("There is a possibility of receiving newsletter in spam folder");
  }
}

function reset(event) {
  emailError.textContent = "";
  loginError.textContent = "";
  passError.textContent = "";
  pass2Error.textContent = "";
  termsError.textContent = "";

  emailInput.classList.remove("is-invalid");
  loginInput.classList.remove("is-invalid");
  passInput.classList.remove("is-invalid");
  pass2Input.classList.remove("is-invalid");
  termsInput.classList.remove("is-invalid");

  emailInput.value = "";
  loginInput.value = "";
  passInput.value = "";
  pass2Input.value = "";
  termsInput.checked = false;
}
emailError.textContent = "";
emailError.classList.remove("error-message");

form.addEventListener("submit", submit);
termsInput.addEventListener("change", termsAlert);
form.addEventListener("reset", reset);
emailError.textContent = "";
emailError.classList.remove("error-message");
emailError.style.border = "none";
if (!validateEmail(email)) {
  emailError.textContent =
    " Email address should be non-empty with the format xyx@xyz.xyz.";
  emailInput.classList.add("is-invalid");
}
