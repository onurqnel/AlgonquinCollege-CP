<?php
require_once('./dao/employeeDAO.php');
$employeeDAO = new employeeDAO();


if (isset($_GET["id"]) && !empty(trim($_GET["id"]))) {
    // Get URL parameter
    $id = trim($_GET["id"]);
    $employee = $employeeDAO->getEmployee($id);

    if ($employee) {

        $name = $employee->getName();
        $address = $employee->getAddress();
        $salary = $employee->getSalary();
        $start_date = $employee->getStart_date();



        $image = $employee->getImage();



    } else {

        header("location: error.php");
        exit();
    }
} else {
    header("location: error.php");
    exit();
}

$employeeDAO->getMysqli()->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>View Record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper {
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="mt-5 mb-3">View Record</h1>
                    <div class="form-group">
                        <label>Name</label>
                        <p><b>
                                <?php echo $name; ?>
                            </b></p>
                    </div>
                    <div class="form-group">
                        <label>Address</label>
                        <p><b>
                                <?php echo $address; ?>
                            </b></p>
                    </div>
                    <div class="form-group">
                        <label>Salary</label>
                        <p><b>
                                <?php echo $salary; ?>
                            </b></p>
                    </div>
                    <div class="form-group">
                        <label>Start date</label>
                        <p><b>
                                <?php echo $start_date; ?>
                            </b></p>
                    </div>
                    <div class="form-group">
                        <label>Image</label>
                        <p><b><img src="<?php echo $image; ?>" class="image" /></b></p>
                    </div>
                    <p><a href="index.php" class="btn btn-primary">Back</a></p>
                </div>
            </div>
        </div>
    </div>
</body>

</html>