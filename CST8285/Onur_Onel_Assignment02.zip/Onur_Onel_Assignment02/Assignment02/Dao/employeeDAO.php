<?php
require_once('abstractDAO.php');
require_once('./model/employee.php');

class employeeDAO extends abstractDAO
{

    function __construct()
    {
        try {
            parent::__construct();
        } catch (mysqli_sql_exception $e) {
            throw $e;
        }
    }

    public function getEmployee($employeeId)
    {
        $query = 'SELECT * FROM employees WHERE id = ?';
        $stmt = $this->mysqli->prepare($query);
        $stmt->bind_param('i', $employeeId);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows == 1) {
            $temp = $result->fetch_assoc();
            $imagePath = './image/' . $temp['id'] . '.jpeg';
            $employee = new employee($temp['id'], $temp['name'], $temp['address'], $temp['salary'], $temp['start_date'], $temp['image']);

            $result->free();
            return $employee;
        }
        $result->free();
        return false;
    }

    public function getEmployees()
    {
        $result = $this->mysqli->query('SELECT * FROM employees');
        $employees = array();

        if ($result->num_rows >= 1) {
            while ($row = $result->fetch_assoc()) {
                $imagePath = './image/' . $row['id'] . '.jpeg';
                $employee = new Employee($row['id'], $row['name'], $row['address'], $row['salary'], $row['start_date'], $row['image']);

                $employees[] = $employee;
            }
            $result->free();
            return $employees;
        }
        $result->free();
        return false;
    }

    public function addEmployee($employee, $imageFile)
    {
        $target_dir = "./image/";
        $target_file = $target_dir . basename($imageFile["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
            return "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
        }
        if (!move_uploaded_file($imageFile["tmp_name"], $target_file)) {
            return "Sorry, there was an error uploading your file.";
        }


        $sql = "INSERT INTO employees (name, address, salary, start_date, image) VALUES (?, ?, ?, ?, ?)";

        if ($stmt = $this->mysqli->prepare($sql)) {

            $stmt->bind_param("ssiss", $param_name, $param_address, $param_salary, $param_start_date, $param_image);

            $param_name = $employee->getName();
            $param_address = $employee->getAddress();
            $param_salary = $employee->getSalary();
            $param_start_date = $employee->getStart_date();
            $param_image = $employee->getImage();

            if ($stmt->execute()) {
                return "Employee added successfully.";
            } else {
                return "Something went wrong. Please try again later.";
            }
        }
        $stmt->close();
    }


    public function updateEmployee($employee)
    {
        $query = "UPDATE employees SET name=?, address=?, salary=?, start_date=?, image=? WHERE id=?";
        $stmt = $this->mysqli->prepare($query);
        if ($stmt) {
            $id = $employee->getId();
            $name = $employee->getName();
            $address = $employee->getAddress();
            $salary = $employee->getSalary();
            $start_date = $employee->getStart_date();
            $image = $employee->getImage();

            $stmt->bind_param(
                'ssissi',
                $name,
                $address,
                $salary,
                $start_date,
                $image,
                $id
            );
            $stmt->execute();

            if ($stmt->error) {
                return $stmt->error;
            } else {
                return $employee->getName() . ' updated successfully!';
            }
        } else {
            $error = $this->mysqli->errno . ' ' . $this->mysqli->error;
            echo $error;
            return $error;
        }
    }


    public function deleteEmployee($employeeId)
    {
        if (!$this->mysqli->connect_errno) {
            $query = 'DELETE FROM employees WHERE id = ?';
            $stmt = $this->mysqli->prepare($query);
            $stmt->bind_param('i', $employeeId);
            $stmt->execute();
            if ($stmt->error) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

}
?>