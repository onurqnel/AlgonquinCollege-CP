<?php

require_once('./dao/employeeDAO.php');


$name = $address = $salary = $start_date = $image = "";
$name_err = $address_err = $salary_err = $start_date_err = $image_err = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (!empty($_FILES['image']['tmp_name'])) {
        $image = './image/' . basename($_FILES['image']['name']);
    } else {
        $image_err = "Please upload an image.";
    }

    $input_start_date = trim($_POST["start_date"]);
    if (empty($input_start_date)) {
        $start_date_err = "Please select the start date.";
    } else {
        $input_start_date_timestamp = strtotime($input_start_date);
        $min_start_date_timestamp = strtotime('2000-01-01');
        if ($input_start_date_timestamp < $min_start_date_timestamp) {
            $start_date_err = "Start date must be after January 1st, 2000.";
        } else {
            $start_date = $input_start_date;
        }
    }


    $input_name = trim($_POST["name"]);
    if (empty($input_name)) {
        $name_err = "Please enter a name.";
    } elseif (!filter_var($input_name, FILTER_VALIDATE_REGEXP, array("options" => array("regexp" => "/^[a-zA-Z\s]+$/")))) {
        $name_err = "Please enter a valid name.";
    } else {
        $name = $input_name;
    }


    $input_address = trim($_POST["address"]);
    if (empty($input_address)) {
        $address_err = "Please enter an address.";
    } else {
        $address = $input_address;
    }

    $input_salary = trim($_POST["salary"]);
    if (empty($input_salary)) {
        $salary_err = "Please enter the salary amount.";
    } elseif (!ctype_digit($input_salary)) {
        $salary_err = "Please enter a positive integer value.";
    } else {
        $salary = $input_salary;
    }


    if (empty($name_err) && empty($address_err) && empty($salary_err) && empty($start_date_err) && empty($image_err)) {
        $employeeDAO = new employeeDAO();
        $employee = new Employee(0, $name, $address, $salary, $start_date, $image);
        $addResult = $employeeDAO->addEmployee($employee, $_FILES['image']);
        header("refresh:2; url=index.php");
        echo '<br><h6 style="text-align:center">' . $addResult . '</h6>';

        $employeeDAO->getMysqli()->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper {
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5">Create Record</h2>

                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post"
                        enctype="multipart/form-data">
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" name="name"
                                class="form-control <?php echo (!empty($name_err)) ? 'is-invalid' : ''; ?>"
                                value="<?php echo $name; ?>">
                            <span class="invalid-feedback">
                                <?php echo $name_err; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label>Address</label>
                            <textarea name="address"
                                class="form-control <?php echo (!empty($address_err)) ? 'is-invalid' : ''; ?>"><?php echo $address; ?></textarea>
                            <span class="invalid-feedback">
                                <?php echo $address_err; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label>Salary</label>
                            <input type="text" name="salary"
                                class="form-control <?php echo (!empty($salary_err)) ? 'is-invalid' : ''; ?>"
                                value="<?php echo $salary; ?>">
                            <span class="invalid-feedback">
                                <?php echo $salary_err; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label>Start Date</label>
                            <input type="date" name="start_date"
                                class="form-control <?php echo (!empty($start_date_err)) ? 'is-invalid' : ''; ?>"
                                value="<?php echo $start_date; ?>" min="2000-01-01">
                            <span class="invalid-feedback">
                                <?php echo $start_date_err; ?>
                            </span>
                        </div>

                        <div class="form-group">
                            <label>Image</label>
                            <input type="file" name="image" accept="image/*" required
                                class="form-control <?php echo (!empty($Image_err)) ? 'is-invalid' : ''; ?>">
                            <span class="invalid-feedback">
                                <?php echo $Image_err; ?>
                            </span>
                        </div>
                        </br>

                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-secondary ml-2">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
        <? include 'footer.php'; ?>
    </div>

</body>

</html>