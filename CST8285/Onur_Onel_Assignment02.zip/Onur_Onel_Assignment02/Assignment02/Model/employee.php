<?php
class Employee
{

    private $id;
    private $name;
    private $address;
    private $salary;
    private $start_date;
    private $image;

    function __construct($id, $name, $address, $salary, $start_date, $image)
    {
        $this->setId($id);
        $this->setName($name);
        $this->setAddress($address);
        $this->setSalary($salary);
        $this->setStart_date($start_date);
        $this->setImage($image);
    }

    public function getName()
    {
        return $this->name;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function getAddress()
    {
        return $this->address;
    }

    public function setAddress($address)
    {
        $this->address = $address;
    }

    public function getSalary()
    {
        return $this->salary;
    }

    public function setSalary($salary)
    {
        $this->salary = $salary;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    public function getStart_date()
    {
        return $this->start_date;
    }

    public function setStart_date($start_date)
    {
        // Ensure start date is after 2000-01-01
        $min_start_date = '2000-01-01';
        if ($start_date < $min_start_date) {
            $this->start_date = $min_start_date;
        } else {
            $this->start_date = $start_date;
        }
    }

    public function getImage()
    {
        return $this->image;
    }

    public function setImage($image)
    {
        $this->image = $image;
    }

}
?>